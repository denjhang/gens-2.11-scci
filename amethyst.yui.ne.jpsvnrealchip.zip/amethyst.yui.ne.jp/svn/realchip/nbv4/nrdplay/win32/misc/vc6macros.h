/**
 * @file	vc6macros.h
 * @brief	VC6 �p�}�N��
 */

#pragma once

#ifndef _countof
//! countof
#define _countof(x)		(sizeof((x)) / sizeof((x)[0]))
#endif	// _countof

// ---- VC5

#if (_MSC_VER < 1300)

#define INT_PTR				INT			//!< INT_PTR
#define UINT_PTR			UINT		//!< UINT_PTR

#endif	// (_MSC_VER < 1300)

// ---- VC6

#if (_MSC_VER < 1300)
//! for scope
#define for					if (0 /*NEVER*/) { /* no process */ } else for

#ifdef _UNICODE
#define	_tstoi	wtoi		//!< text to int
#define _tstof	wtof		//!< text to float
#else	// _UNICODE
#define	_tstoi	atoi		//!< text to int
#define _tstof	atof		//!< text to float
#endif	// _UNICODE

typedef char				INT8;		//!< INT8
typedef short				INT16;		//!< INT16
// typedef int				INT32;
typedef __int64				INT64;		//!< INT64
typedef unsigned char		UINT8;		//!< UINT8
typedef unsigned short		UINT16;		//!< UINT16
// typedef unsigned int		UINT32;
typedef unsigned __int64	UINT64;		//!< UINT64

#endif	// (_MSC_VER < 1300)

// for VC6SDK
#if (_MSC_VER < 1300)
#ifndef LONG_PTR
#define LONG_PTR			LONG							/*!< LONG_PTR */
#endif
#ifndef DWORD_PTR
#define DWORD_PTR			DWORD							/*!< DWORD_PTR */
#endif
#endif

#if (_MSC_VER < 1300)
#if defined(_USE_MATH_DEFINES) && !defined(_MATH_DEFINES_DEFINED)
#define _MATH_DEFINES_DEFINED
#define M_PI		3.14159265358979323846
#endif
#endif

// algorithm
#if defined(__cplusplus) && (_MSC_VER < 1300)
#undef max
#undef min
namespace std
{
	template<class T> const T& max(const T& a, const T& b) { return (a > b) ? a : b; }
	template<class T> const T& min(const T& a, const T& b) { return (a < b) ? a : b; }
}
#endif	/* defined(__cplusplus) && (_MSC_VER < 1300) */
