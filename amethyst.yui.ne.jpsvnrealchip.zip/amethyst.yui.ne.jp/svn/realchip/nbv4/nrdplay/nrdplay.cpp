/**
 * @file	nrdplay.cpp
 * @brief	NRD �Đ��N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "nrdplay.h"
#include <iostream>
#include "ext/externalchipmanager.h"
#include "misc/mmapfile.h"
#include "misc/tickcounter.h"

/**
 * �R���X�g���N�^
 */
NrdPlay::NrdPlay()
	: m_cOpm1Index(0)
	, m_cOpm2Index(0)
	, m_cPsgIndex(0)
	, m_pOpm1(NULL)
	, m_pOpm2(NULL)
	, m_pPsg(NULL)
{
	memset(m_mem, 0, sizeof(m_mem));
}

/**
 * �f�X�g���N�^
 */
NrdPlay::~NrdPlay()
{
}

/**
 * ���s
 * @param[in] lpFilename �t�@�C����
 * @param[in] pAbort �A�{�[�g �t���O
 * @return ���U���g �R�[�h
 */
int NrdPlay::Execute(LPCTSTR lpFilename, volatile bool* pAbort)
{
	if ((lpFilename) && (!LoadFile(0x4000, lpFilename)))
	{
		std::cerr << "Cloudn't open file." << std::endl;
		return 1;
	}

	if (!LoadFile(0x1800, TEXT("NRTDRV.BIN")))
	{
		std::cerr << "Cloudn't open NRTDRV.BIN." << std::endl;
		return 1;
	}

	std::cout << reinterpret_cast<const char*>(m_mem + 0x4029) << std::endl;

	CExternalChipManager* pManager = CExternalChipManager::GetInstance();
	pManager->Initialize();
	m_pOpm1 = pManager->GetInterface(IExternalChip::kYM2151, 4000000);
	m_pOpm2 = pManager->GetInterface(IExternalChip::kYM2151, 4000000);
	m_pPsg = pManager->GetInterface(IExternalChip::kAY8910, 2000000);

	TickCounter tick;

	Call(0x1800);
	tick.Delay(50);

	if (lpFilename)
	{
		Call(0x1803);
	}
	else
	{
		Call(0x180f);
	}
	tick.Delay(50);

	UINT nTick = tick.Get();
	while ((pAbort == NULL) || (!*pAbort))
	{
		if (nTick != tick.Get())
		{
			nTick++;
			UINT8 nFlags = m_ctc.Execute(4000000 / 1000);
			if (nFlags & (1 << 1))
			{
				const UINT nAddr = (Z80_I << 8) | m_ctc.GetVector(1);
				Call(m_mem[nAddr] | (m_mem[nAddr + 1] << 8));
			}
			if (nFlags & (1 << 3))
			{
				const UINT nAddr = (Z80_I << 8) | m_ctc.GetVector(3);
				Call(m_mem[nAddr] | (m_mem[nAddr + 1] << 8));
			}
		}
		else
		{
			tick.Delay(1);
		}
	}

	pManager->Deinitialize();
	return 0;
}

/**
 * �t�@�C�����[�h
 * @param[in] nAddr �A�h���X
 * @param[in] lpFilename �t�@�C����
 * @retval true ����
 * @retval false ���s
 */
bool NrdPlay::LoadFile(UINT nAddr, LPCTSTR lpFilename)
{
	CMMapFile file;
	if (!file.Open(lpFilename))
	{
		return false;
	}
	if ((nAddr + file.GetSize()) > 0x10000)
	{
		return false;
	}
	memcpy(m_mem + nAddr, file.GetPtr(), file.GetSize());
	return true;
}

/**
 * Read
 * @param[in] nAddr �A�h���X
 * @return �f�[�^
 */
REG8 NrdPlay::OnRead(UINT nAddr)
{
	return m_mem[nAddr];
}

/**
 * Write
 * @param[in] nAddr �A�h���X
 * @param[in] cData �f�[�^
 */
void NrdPlay::OnWrite(UINT nAddr, REG8 cData)
{
	m_mem[nAddr] = cData;
}

/**
 * OUT
 * @param[in] nAddr �A�h���X
 * @param[in] cData �f�[�^
 */
void NrdPlay::OnOut(UINT nAddr, REG8 cData)
{
	switch (nAddr)
	{
		case 0x0704:
		case 0x070c:
		case 0x1fa0:
		case 0x1fa1:
		case 0x1fa2:
		case 0x1fa3:
			m_ctc.Out(nAddr, cData);
			break;

		case 0x0700:
			m_cOpm1Index = cData;
			break;

		case 0x0701:
			if (m_pOpm1)
			{
				m_pOpm1->WriteRegister(m_cOpm1Index, cData);
			}
			break;

		case 0x0708:
			m_cOpm2Index = cData;
			break;

		case 0x0709:
			if (m_pOpm2)
			{
				m_pOpm2->WriteRegister(m_cOpm2Index, cData);
			}
			break;

		default:
			if ((nAddr & 0xff00) == 0x1b00)
			{
				if (m_pPsg)
				{
					m_pPsg->WriteRegister(m_cPsgIndex, cData);
				}
			}
			else if ((nAddr & 0xff00) == 0x1c00)
			{
				m_cPsgIndex = cData;
			}
			else
			{
				Z80Cpu::OnOut(nAddr, cData);
			}
			break;
	}
}

/**
 * IN
 * @param[in] nAddr �A�h���X
 * @return �f�[�^
 */
REG8 NrdPlay::OnIn(UINT nAddr)
{
	switch (nAddr)
	{
		case 0x0704:
		case 0x070c:
		case 0x1fa0:
		case 0x1fa1:
		case 0x1fa2:
		case 0x1fa3:
			return m_ctc.In(nAddr);

		default:
			return Z80Cpu::OnIn(nAddr);
	}
}
