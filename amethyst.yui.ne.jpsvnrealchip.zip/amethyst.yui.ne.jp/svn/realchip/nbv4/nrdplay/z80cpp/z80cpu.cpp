/**
 * @file	z80cpu.cpp
 * @brief	Z80 CPU �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "z80cpu.h"
#include "z80c.h"
#include "z80c.mcr"

static bool sm_bInitialized = false;

	UINT8 	z80inc_flag2[256];
	UINT8	z80dec_flag2[256];
	UINT8	z80szc_flag[512];
	UINT8	z80szp_flag[256];

	const UINT8 cycles_main[256] = {
					 4,10, 7, 6, 4, 4, 7, 4, 4,11, 7, 6, 4, 4, 7, 4,
					 8,10, 7, 6, 4, 4, 7, 4, 7,11, 7, 6, 4, 4, 7, 4,
					 7,10,16, 6, 4, 4, 7, 4, 7,11,16, 6, 4, 4, 7, 4,
					 7,10,13, 6,11,11,10, 4, 7,11,13, 6, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 7, 7, 7, 7, 7, 7, 4, 7, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
					 5,10,10,10,10,11, 7,11, 5, 4,10, 0,10,10, 7,11,
					 5,10,10,11,10,11, 7,11, 5, 4,10,11,10, 0, 7,11,
					 5,10,10,19,10,11, 7,11, 5, 4,10, 4,10, 0, 7,11,
					 5,10,10, 4,10,11, 7,11, 5, 6,10, 4,10, 0, 7,11};

	const UINT8 cycles_xx[256] = {
					 0, 0, 0, 0, 0, 0, 0, 0, 0,15, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0,15, 0, 0, 0, 0, 0, 0,
					 0,14,20,10, 9, 9, 9, 0, 0,15,20,10, 9, 9, 9, 0,
					 0, 0, 0, 0,23,23,19, 0, 0,15, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 9, 9, 9, 9, 9, 9,19, 9, 9, 9, 9, 9, 9, 9,19, 9,
					19,19,19,19,19,19,19,19, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 9, 9,19, 0, 0, 0, 0, 0, 9, 9,19, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0,14, 0,23, 0,15, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0,10, 0, 0, 0, 0, 0, 0};

	const UINT8 cycles_ed[256] = {
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					12,12,15,20, 8, 8, 8, 9,12,12,15,20, 8, 8, 8, 9,
					12,12,15,20, 8, 8, 8, 9,12,12,15,20, 8, 8, 8, 9,
					12,12,15,20, 8, 8, 8,18,12,12,15,20, 8, 8, 8,18,
					12,12,15,20, 8, 8, 8, 0,12,12,15,20, 8, 8, 8, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					16,16,16,16, 0, 0, 0, 0,16,16,16,16, 0, 0, 0, 0,
					16,16,16,16, 0, 0, 0, 0,16,16,16,16, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

/**
 * ������
 */
static void Initialize()
{
	if (sm_bInitialized)
	{
		return;
	}
	sm_bInitialized = true;

	UINT	i;
	REG8	f;
	REG8	c;

	for (i=0; i<256; i++) {
		f = V_FLAG;
		if (!i) {
			f |= Z_FLAG;
		}
		if (i & 0x80) {
			f |= S_FLAG;
		}
		for (c=0x80; c; c>>=1) {
			if (i & c) {
				f ^= V_FLAG;
			}
		}

		z80szp_flag[i] = (UINT8)f;

		z80inc_flag2[(i - 1) & 0xff] = (UINT8)(f & (~V_FLAG));
		if (!(i & 0x0f)) {
			z80inc_flag2[(i - 1) & 0xff] |= H_FLAG;
		}
		z80dec_flag2[(i + 1) & 0xff] = (UINT8)(f & (~V_FLAG)) | N_FLAG;
		if ((i & 0x0f) == 0x0f) {
			z80dec_flag2[(i + 1) & 0xff] |= H_FLAG;
		}

		z80szc_flag[i] = (UINT8)(f & (~V_FLAG));
		z80szc_flag[i+256] = (UINT8)(f & (~V_FLAG)) | C_FLAG;
	}
	z80inc_flag2[0x80 - 1] |= V_FLAG;
	z80dec_flag2[0x7f + 1] |= V_FLAG;
}

/**
 * �R���X�g���N�^
 */
Z80Cpu::Z80Cpu()
{
	Initialize();
	Reset();
}

/**
 * ���Z�b�g
 */
void Z80Cpu::Reset()
{
	memset(&this->s, 0, sizeof(this->s));
}

#if 0
void CPUCALL z80c_interrupt(Z80CORE *cpu, REG8 vect) {

	REG16	pc;

	if (R_Z80IFF & (1 << IFF_HALT)) {
		R_Z80IFF ^= (1 << IFF_HALT);
		R_Z80PC++;
	}
	R_Z80IFF |= (1 << IFF_IFLAG);
	switch(R_Z80IM) {
		case 0:
			if ((vect != 0xdd) && (vect != 0xed) && (vect != 0xfd)) {
				Z80_COUNT(cycles_main[vect]);
				(*z80c_mainop[vect])(cpu);
			}
			break;

		case 1:
			Z80_COUNT(11);
			R_Z80SP -= 2;
			R_Z80MEMWR16(R_Z80SP, R_Z80PC);
			R_Z80PC = 0x38;
			break;

		case 2:
			pc = R_Z80MEMRD16((R_Z80I << 8) + vect);
			R_Z80SP -= 2;
			R_Z80MEMWR16(R_Z80SP, R_Z80PC);
			R_Z80PC = pc;
			break;
	}
}

void CPUCALL z80c_nonmaskedinterrupt(Z80CORE *cpu) {

	if (!(R_Z80IFF & (1 << IFF_NMI))) {
		R_Z80IFF |= (1 << IFF_NMI);
		if (R_Z80IFF & (1 << IFF_HALT)) {
			R_Z80IFF ^= (1 << IFF_HALT);
			R_Z80PC++;
		}
		R_Z80SP -= 2;
		R_Z80MEMWR16(R_Z80SP, R_Z80PC);
		R_Z80PC = 0x66;
	}
}
#endif

/**
 * �X�e�b�v���s
 */
void Z80Cpu::Step()
{
	Z80Cpu* cpu = this;
	UINT	op;

	R_Z80R++;
	GET_PC_BYTE(op);
	Z80_COUNT(cycles_main[op]);
	(*z80c_mainop[op])(cpu);
}

/**
 * �R�[��
 * @param[in] nAddr �A�h���X
 */
void Z80Cpu::Call(UINT nAddr)
{
	const UINT pc = Z80_PC;

	Z80_PC = nAddr;

	Push(0xffff);
	do
	{
		Step();
	} while (Z80_PC != 0xffff);

	Z80_PC = pc;
}

/**
 * �v�b�V��
 * @param[in] wData �f�[�^
 */
void Z80Cpu::Push(REG16 wData)
{
	Z80_SP -= 2;
	OnWrite16(Z80_SP, wData);
}

/**
 * ���[�h
 * @param[in] nAddr �A�h���X
 * @return �f�[�^
 */
REG8 Z80Cpu::OnRead(UINT nAddr)
{
	return 0xff;
}

/**
 * ���[�h
 * @param[in] nAddr �A�h���X
 * @return �f�[�^
 */
REG16 Z80Cpu::OnRead16(UINT nAddr)
{
	REG16 r = OnRead(nAddr);
	r |= OnRead(LOW16(nAddr + 1)) << 8;
	return r;
}

/**
 * ���C�g
 * @param[in] nAddr �A�h���X
 * @param[in] wData �f�[�^
 */
void Z80Cpu::OnWrite(UINT nAddr, REG8 cData)
{
}

/**
 * ���C�g
 * @param[in] nAddr �A�h���X
 * @param[in] wData �f�[�^
 */
void Z80Cpu::OnWrite16(UINT nAddr, REG16 wData)
{
	OnWrite(nAddr, static_cast<REG8>(wData));
	OnWrite(LOW16(nAddr + 1), static_cast<REG8>(wData >> 8));
}

/**
 * OUT
 * @param[in] nAddr �A�h���X
 * @param[in] wData �f�[�^
 */
void Z80Cpu::OnOut(UINT nPort, REG8 cData)
{
}

/**
 * IN
 * @param[in] nAddr �A�h���X
 * @return �f�[�^
 */
REG8 Z80Cpu::OnIn(UINT nPort)
{
	return 0xff;
}
