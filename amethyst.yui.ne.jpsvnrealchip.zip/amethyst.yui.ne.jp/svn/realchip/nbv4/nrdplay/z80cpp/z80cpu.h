/**
 * @file	z80cpu.h
 * @brief	Z80 CPU �N���X�̐錾����уC���^�[�t�F�C�X�̒�`�����܂�
 */

#pragma once

/**
 * �t���O
 */
enum
{
	S_FLAG		= 0x80,
	Z_FLAG		= 0x40,
	H_FLAG		= 0x10,
	V_FLAG		= 0x04,
	N_FLAG		= 0x02,
	C_FLAG		= 0x01
};

/**
 * ���荞�݃X�e�[�^�X
 */
enum
{
	IFF_IFLAG	= 0,
	IFF_NMI		= 1,
	IFF_HALT	= 2
};

/**
 * @brief Z80 ���W�X�^(8�r�b�g)
 */
struct Z80Reg8
{
#if defined(BYTESEX_LITTLE)
	UINT8	c;
	UINT8	b;
	UINT8	e;
	UINT8	d;
	UINT8	l;
	UINT8	h;
	UINT8	f;
	UINT8	a;
	UINT8	ixl;
	UINT8	ixh;
	UINT8	iyl;
	UINT8	iyh;
#else
	UINT8	b;
	UINT8	c;
	UINT8	d;
	UINT8	e;
	UINT8	h;
	UINT8	l;
	UINT8	a;
	UINT8	f;
	UINT8	ixh;
	UINT8	ixl;
	UINT8	iyh;
	UINT8	iyl;
#endif
};

/**
 * @brief Z80 ���W�X�^(16�r�b�g)
 */
struct Z80Reg16
{
	UINT16 bc;
	UINT16 de;
	UINT16 hl;
	UINT16 af;
	UINT16 ix;
	UINT16 iy;
};

/**
 * @brief Z80 �\����
 */
struct Z80Stat
{
	union
	{
		Z80Reg8		b;
		Z80Reg16	w;
	}	r;
	UINT16	pc;
	UINT16	sp;
	UINT16	af2;
	UINT16	bc2;
	UINT16	de2;
	UINT16	hl2;
	UINT8	i;
	UINT8	im;
	UINT8	r1;
	UINT8	r2;
	UINT8	iff;
	UINT8	padding[3];
	UINT32	irq;
	UINT32	reqirq;

	SINT32	remainclock;
	SINT32	baseclock;
	UINT32	clock;
};

/**
 * @brief Z80 CPU �\����
 */
struct Z80Cpu
{
	Z80Stat s;
	Z80Cpu();
	void Reset();
	void Step();
	void Call(UINT nAddr);
	void Push(REG16 wData);
	virtual REG8 OnRead(UINT nAddr);
	virtual REG16 OnRead16(UINT nAddr);
	virtual void OnWrite(UINT nAddr, REG8 cData);
	virtual void OnWrite16(UINT nAddr, REG16 wData);
	virtual void OnOut(UINT nPort, REG8 cData);
	virtual REG8 OnIn(UINT nPort);
};

#define	Z80_A			s.r.b.a
#define	Z80_F			s.r.b.f
#define	Z80_B			s.r.b.b
#define	Z80_C			s.r.b.c
#define	Z80_D			s.r.b.d
#define	Z80_E			s.r.b.e
#define	Z80_H			s.r.b.h
#define	Z80_L			s.r.b.l

#define	Z80_AF			s.r.w.af
#define	Z80_BC			s.r.w.bc
#define	Z80_DE			s.r.w.de
#define	Z80_HL			s.r.w.hl
#define	Z80_IX			s.r.w.ix
#define	Z80_IY			s.r.w.iy

#define	Z80_PC			s.pc
#define	Z80_SP			s.sp
#define	Z80_AF2			s.af2
#define	Z80_BC2			s.bc2
#define	Z80_DE2			s.de2
#define	Z80_HL2			s.hl2

#define	Z80_I			s.i
#define Z80_IM			s.im
#define Z80_R			s.r1
#define Z80_R2			s.r2
#define	Z80_IFF			s.iff

#define	CPU_IRQ			s.irq
#define	CPU_REQIRQ		s.reqirq

#define	CPU_REMCLOCK	s.remainclock
#define	CPU_BASECLOCK	s.baseclock
#define	CPU_CLOCK		s.clock
#define	CPU_CLOCKCOUNT	(CPU_CLOCK + CPU_BASECLOCK - CPU_REMCLOCK)

#define	Z80_DI			((Z80_IFF & 3) != 0)
#define	Z80_EI			((Z80_IFF & 3) == 0)
