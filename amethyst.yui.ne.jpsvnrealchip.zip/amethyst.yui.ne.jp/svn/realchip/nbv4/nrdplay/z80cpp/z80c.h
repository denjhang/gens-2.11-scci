/* -----------------------------------------------------------------------
 *
 * Z80C : Z80 Engine - GENERIC
 *
 *                              Copyright by Studio Milmake 1999-2000,2004
 *
 *------------------------------------------------------------------------ */

#pragma once

#include "z80cpu.h"

extern UINT8 z80inc_flag2[256];
extern UINT8 z80dec_flag2[256];
extern UINT8 z80szc_flag[512];
extern UINT8 z80szp_flag[256];

extern const UINT8 cycles_main[256];
extern const UINT8 cycles_xx[256];
extern const UINT8 cycles_ed[256];

#define	Z80FN	static void
#define Z80EXT	void

typedef void (*Z80OP)(Z80Cpu* cpu);

extern const Z80OP z80c_mainop[256];
extern void z80c_cb(Z80Cpu* cpu);
extern void z80c_ix(Z80Cpu* cpu);
extern void z80c_sub(Z80Cpu* cpu);
extern void z80c_iy(Z80Cpu* cpu);
extern void z80c_ixcb(Z80Cpu* cpu);
extern void z80c_iycb(Z80Cpu* cpu);

#define	R_Z80A		cpu->s.r.b.a
#define	R_Z80F		cpu->s.r.b.f
#define	R_Z80B		cpu->s.r.b.b
#define	R_Z80C		cpu->s.r.b.c
#define	R_Z80D		cpu->s.r.b.d
#define	R_Z80E		cpu->s.r.b.e
#define	R_Z80H		cpu->s.r.b.h
#define	R_Z80L		cpu->s.r.b.l

#define	R_Z80AF		cpu->s.r.w.af
#define	R_Z80BC		cpu->s.r.w.bc
#define	R_Z80DE		cpu->s.r.w.de
#define	R_Z80HL		cpu->s.r.w.hl
#define	R_Z80IX		cpu->s.r.w.ix
#define	R_Z80IY		cpu->s.r.w.iy

#define	R_Z80PC		cpu->s.pc
#define	R_Z80SP		cpu->s.sp
#define	R_Z80AF2	cpu->s.af2
#define	R_Z80BC2	cpu->s.bc2
#define	R_Z80DE2	cpu->s.de2
#define	R_Z80HL2	cpu->s.hl2

#define	R_Z80I		cpu->s.i
#define R_Z80IM		cpu->s.im
#define R_Z80R		cpu->s.r1
#define R_Z80R2		cpu->s.r2
#define	R_Z80IFF	cpu->s.iff

#define	R_Z80REQIRQ		cpu->s.reqirq

#define	R_Z80REMCLOCK	cpu->s.remainclock
#define	R_Z80BASECLOCK	cpu->s.baseclock

#define R_Z80MEMRD8(a)		cpu->OnRead(a)
#define R_Z80MEMRD8S(a)		static_cast<SINT8>(cpu->OnRead(a))
#define R_Z80MEMRD16(a)		cpu->OnRead16(a)
#define R_Z80MEMWR8(a, d)	cpu->OnWrite(a, d)
#define R_Z80MEMWR16(a, d)	cpu->OnWrite16(a, d)

#define R_Z80IN(a)			cpu->OnIn(a)
#define R_Z80OUT(a, d)		cpu->OnOut(a, d)

#define LOW16(v)	static_cast<UINT16>(v)
#define LOW8(v)		static_cast<UINT8>(v)
