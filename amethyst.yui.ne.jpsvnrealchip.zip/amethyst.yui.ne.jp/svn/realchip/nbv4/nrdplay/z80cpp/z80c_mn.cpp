/* -----------------------------------------------------------------------
 *
 * Z80C : Z80 Engine - GENERIC
 *
 *                              Copyright by Studio Milmake 1999-2000,2004
 *
 *------------------------------------------------------------------------ */

#include "stdafx.h"
#include "z80c.h"
#include "z80c.mcr"

Z80FN _ld_nop(Z80Cpu* cpu)			{ }
Z80FN _ld_bc_word(Z80Cpu* cpu)		LDW_w(R_Z80BC)
Z80FN _ld_xbc_a(Z80Cpu* cpu)		LDx_B(R_Z80BC, R_Z80A)
Z80FN _inc_bc(Z80Cpu* cpu)			MCR_INC_W(R_Z80BC)
Z80FN _inc_b(Z80Cpu* cpu)			MCR_INC(R_Z80B)
Z80FN _dec_b(Z80Cpu* cpu)			MCR_DEC(R_Z80B)
Z80FN _ld_b_byte(Z80Cpu* cpu)		LDB_b(R_Z80B)
Z80FN _rlca(Z80Cpu* cpu)			MCR_RLCA
Z80FN _ex_af_af(Z80Cpu* cpu)		MCR_EX(R_Z80AF, R_Z80AF2)
Z80FN _add_hl_bc(Z80Cpu* cpu)		MCR_ADD_W(R_Z80HL, R_Z80BC)
Z80FN _ld_a_xbc(Z80Cpu* cpu)		LDB_x(R_Z80A, R_Z80BC)
Z80FN _dec_bc(Z80Cpu* cpu)			MCR_DEC_W(R_Z80BC)
Z80FN _inc_c(Z80Cpu* cpu)			MCR_INC(R_Z80C)
Z80FN _dec_c(Z80Cpu* cpu)			MCR_DEC(R_Z80C)
Z80FN _ld_c_byte(Z80Cpu* cpu)		LDB_b(R_Z80C)
Z80FN _rrca(Z80Cpu* cpu)			MCR_RRCA

Z80FN _djnz(Z80Cpu* cpu)			MCR_DJNZ
Z80FN _ld_de_word(Z80Cpu* cpu)		LDW_w(R_Z80DE)
Z80FN _ld_xde_a(Z80Cpu* cpu)		LDx_B(R_Z80DE, R_Z80A)
Z80FN _inc_de(Z80Cpu* cpu)			MCR_INC_W(R_Z80DE)
Z80FN _inc_d(Z80Cpu* cpu)			MCR_INC(R_Z80D)
Z80FN _dec_d(Z80Cpu* cpu)			MCR_DEC(R_Z80D)
Z80FN _ld_d_byte(Z80Cpu* cpu)		LDB_b(R_Z80D)
Z80FN _rla(Z80Cpu* cpu)				MCR_RLA
Z80FN _jr(Z80Cpu* cpu)				MCR_JR
Z80FN _add_hl_de(Z80Cpu* cpu)		MCR_ADD_W(R_Z80HL, R_Z80DE)
Z80FN _ld_a_xde(Z80Cpu* cpu)		LDB_x(R_Z80A, R_Z80DE)
Z80FN _dec_de(Z80Cpu* cpu)			MCR_DEC_W(R_Z80DE)
Z80FN _inc_e(Z80Cpu* cpu)			MCR_INC(R_Z80E)
Z80FN _dec_e(Z80Cpu* cpu)			MCR_DEC(R_Z80E)
Z80FN _ld_e_byte(Z80Cpu* cpu)		LDB_b(R_Z80E)
Z80FN _rra(Z80Cpu* cpu)				MCR_RRA

Z80FN _jr_nz(Z80Cpu* cpu)			MCR_JRNFLG(Z_FLAG)
Z80FN _ld_hl_word(Z80Cpu* cpu)		LDW_w(R_Z80HL)
Z80FN _ld_xword_hl(Z80Cpu* cpu)		LDx_W(R_Z80HL)
Z80FN _inc_hl(Z80Cpu* cpu)			MCR_INC_W(R_Z80HL)
Z80FN _inc_h(Z80Cpu* cpu)			MCR_INC(R_Z80H)
Z80FN _dec_h(Z80Cpu* cpu)			MCR_DEC(R_Z80H)
Z80FN _ld_h_byte(Z80Cpu* cpu)		LDB_b(R_Z80H)
Z80FN _daa(Z80Cpu* cpu)				MCR_DDA
Z80FN _jr_z(Z80Cpu* cpu)			MCR_JRFLG(Z_FLAG)
Z80FN _add_hl_hl(Z80Cpu* cpu)		MCR_ADDx2(R_Z80HL)
Z80FN _ld_hl_xword(Z80Cpu* cpu)		LDW_x(R_Z80HL)
Z80FN _dec_hl(Z80Cpu* cpu)			MCR_DEC_W(R_Z80HL)
Z80FN _inc_l(Z80Cpu* cpu)			MCR_INC(R_Z80L)
Z80FN _dec_l(Z80Cpu* cpu)			MCR_DEC(R_Z80L)
Z80FN _ld_l_byte(Z80Cpu* cpu)		LDB_b(R_Z80L)
Z80FN _cpl(Z80Cpu* cpu)				MCR_CPL

Z80FN _jr_nc(Z80Cpu* cpu)			MCR_JRNFLG(C_FLAG)
Z80FN _ld_sp_word(Z80Cpu* cpu)		LDW_w(R_Z80SP)
Z80FN _ld_xbyte_a(Z80Cpu* cpu)		LDB_x_a
Z80FN _inc_sp(Z80Cpu* cpu)			MCR_INC_W(R_Z80SP)
Z80FN _inc_xhl(Z80Cpu* cpu)			MCR_INC_MEM(R_Z80HL)
Z80FN _dec_xhl(Z80Cpu* cpu)			MCR_DEC_MEM(R_Z80HL)
Z80FN _ld_xhl_byte(Z80Cpu* cpu)		LDB_xhl_b
Z80FN _scf(Z80Cpu* cpu)				MCR_SCF
Z80FN _jr_c(Z80Cpu* cpu)			MCR_JRFLG(C_FLAG)
Z80FN _add_hl_sp(Z80Cpu* cpu)		MCR_ADD_W(R_Z80HL, R_Z80SP)
Z80FN _ld_a_xbyte(Z80Cpu* cpu)		LDB_a_x
Z80FN _dec_sp(Z80Cpu* cpu)			MCR_DEC_W(R_Z80SP)
Z80FN _inc_a(Z80Cpu* cpu)			MCR_INC(R_Z80A)
Z80FN _dec_a(Z80Cpu* cpu)			MCR_DEC(R_Z80A)
Z80FN _ld_a_byte(Z80Cpu* cpu)		LDB_b(R_Z80A)
Z80FN _ccf(Z80Cpu* cpu)				MCR_CCF

Z80FN _ld_b_c(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80C)
Z80FN _ld_b_d(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80D)
Z80FN _ld_b_e(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80E)
Z80FN _ld_b_h(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80H)
Z80FN _ld_b_l(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80L)
Z80FN _ld_b_xhl(Z80Cpu* cpu)		LDB_x(R_Z80B, R_Z80HL)
Z80FN _ld_b_a(Z80Cpu* cpu)			MCR_LD(R_Z80B, R_Z80A)
Z80FN _ld_c_b(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80B)
Z80FN _ld_c_d(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80D)
Z80FN _ld_c_e(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80E)
Z80FN _ld_c_h(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80H)
Z80FN _ld_c_l(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80L)
Z80FN _ld_c_xhl(Z80Cpu* cpu)		LDB_x(R_Z80C, R_Z80HL)
Z80FN _ld_c_a(Z80Cpu* cpu)			MCR_LD(R_Z80C, R_Z80A)

Z80FN _ld_d_b(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80B)
Z80FN _ld_d_c(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80C)
Z80FN _ld_d_e(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80E)
Z80FN _ld_d_h(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80H)
Z80FN _ld_d_l(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80L)
Z80FN _ld_d_xhl(Z80Cpu* cpu)		LDB_x(R_Z80D, R_Z80HL)
Z80FN _ld_d_a(Z80Cpu* cpu)			MCR_LD(R_Z80D, R_Z80A)
Z80FN _ld_e_b(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80B)
Z80FN _ld_e_c(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80C)
Z80FN _ld_e_d(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80D)
Z80FN _ld_e_h(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80H)
Z80FN _ld_e_l(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80L)
Z80FN _ld_e_xhl(Z80Cpu* cpu)		LDB_x(R_Z80E, R_Z80HL)
Z80FN _ld_e_a(Z80Cpu* cpu)			MCR_LD(R_Z80E, R_Z80A)

Z80FN _ld_h_b(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80B)
Z80FN _ld_h_c(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80C)
Z80FN _ld_h_d(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80D)
Z80FN _ld_h_e(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80E)
Z80FN _ld_h_l(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80L)
Z80FN _ld_h_xhl(Z80Cpu* cpu)		LDB_x(R_Z80H, R_Z80HL)
Z80FN _ld_h_a(Z80Cpu* cpu)			MCR_LD(R_Z80H, R_Z80A)
Z80FN _ld_l_b(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80B)
Z80FN _ld_l_c(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80C)
Z80FN _ld_l_d(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80D)
Z80FN _ld_l_e(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80E)
Z80FN _ld_l_h(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80H)
Z80FN _ld_l_xhl(Z80Cpu* cpu)		LDB_x(R_Z80L, R_Z80HL)
Z80FN _ld_l_a(Z80Cpu* cpu)			MCR_LD(R_Z80L, R_Z80A)

Z80FN _ld_xhl_b(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80B)
Z80FN _ld_xhl_c(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80C)
Z80FN _ld_xhl_d(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80D)
Z80FN _ld_xhl_e(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80E)
Z80FN _ld_xhl_h(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80H)
Z80FN _ld_xhl_l(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80L)
Z80FN _halt(Z80Cpu* cpu)			MCR_HALT
Z80FN _ld_xhl_a(Z80Cpu* cpu)		LDx_B(R_Z80HL, R_Z80A)
Z80FN _ld_a_b(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80B)
Z80FN _ld_a_c(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80C)
Z80FN _ld_a_d(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80D)
Z80FN _ld_a_e(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80E)
Z80FN _ld_a_h(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80H)
Z80FN _ld_a_l(Z80Cpu* cpu)			MCR_LD(R_Z80A, R_Z80L)
Z80FN _ld_a_xhl(Z80Cpu* cpu)		LDB_x(R_Z80A, R_Z80HL)

Z80FN _add_a_b(Z80Cpu* cpu)			MCR_ADD(R_Z80B)
Z80FN _add_a_c(Z80Cpu* cpu)			MCR_ADD(R_Z80C)
Z80FN _add_a_d(Z80Cpu* cpu)			MCR_ADD(R_Z80D)
Z80FN _add_a_e(Z80Cpu* cpu)			MCR_ADD(R_Z80E)
Z80FN _add_a_h(Z80Cpu* cpu)			MCR_ADD(R_Z80H)
Z80FN _add_a_l(Z80Cpu* cpu)			MCR_ADD(R_Z80L)
Z80FN _add_a_xhl(Z80Cpu* cpu)		MCR_ADD_XHL
Z80FN _add_a_a(Z80Cpu* cpu)			MCR_ADD(R_Z80A)				/* !! */
Z80FN _adc_a_b(Z80Cpu* cpu)			MCR_ADC(R_Z80B)
Z80FN _adc_a_c(Z80Cpu* cpu)			MCR_ADC(R_Z80C)
Z80FN _adc_a_d(Z80Cpu* cpu)			MCR_ADC(R_Z80D)
Z80FN _adc_a_e(Z80Cpu* cpu)			MCR_ADC(R_Z80E)
Z80FN _adc_a_h(Z80Cpu* cpu)			MCR_ADC(R_Z80H)
Z80FN _adc_a_l(Z80Cpu* cpu)			MCR_ADC(R_Z80L)
Z80FN _adc_a_xhl(Z80Cpu* cpu)		MCR_ADC_XHL
Z80FN _adc_a_a(Z80Cpu* cpu)			MCR_ADC(R_Z80A)				/* !! */

Z80FN _sub_b(Z80Cpu* cpu)			MCR_SUB(R_Z80B)
Z80FN _sub_c(Z80Cpu* cpu)			MCR_SUB(R_Z80C)
Z80FN _sub_d(Z80Cpu* cpu)			MCR_SUB(R_Z80D)
Z80FN _sub_e(Z80Cpu* cpu)			MCR_SUB(R_Z80E)
Z80FN _sub_h(Z80Cpu* cpu)			MCR_SUB(R_Z80H)
Z80FN _sub_l(Z80Cpu* cpu)			MCR_SUB(R_Z80L)
Z80FN _sub_xhl(Z80Cpu* cpu)			MCR_SUB_XHL
Z80FN _sub_a(Z80Cpu* cpu)			MCR_SUB(R_Z80A)				/* !! */
Z80FN _sbc_a_b(Z80Cpu* cpu)			MCR_SBC(R_Z80B)
Z80FN _sbc_a_c(Z80Cpu* cpu)			MCR_SBC(R_Z80C)
Z80FN _sbc_a_d(Z80Cpu* cpu)			MCR_SBC(R_Z80D)
Z80FN _sbc_a_e(Z80Cpu* cpu)			MCR_SBC(R_Z80E)
Z80FN _sbc_a_h(Z80Cpu* cpu)			MCR_SBC(R_Z80H)
Z80FN _sbc_a_l(Z80Cpu* cpu)			MCR_SBC(R_Z80L)
Z80FN _sbc_a_xhl(Z80Cpu* cpu)		MCR_SBC_XHL
Z80FN _sbc_a_a(Z80Cpu* cpu)			MCR_SBC(R_Z80A)				/* !! */

Z80FN _and_b(Z80Cpu* cpu)			MCR_AND(R_Z80B)
Z80FN _and_c(Z80Cpu* cpu)			MCR_AND(R_Z80C)
Z80FN _and_d(Z80Cpu* cpu)			MCR_AND(R_Z80D)
Z80FN _and_e(Z80Cpu* cpu)			MCR_AND(R_Z80E)
Z80FN _and_h(Z80Cpu* cpu)			MCR_AND(R_Z80H)
Z80FN _and_l(Z80Cpu* cpu)			MCR_AND(R_Z80L)
Z80FN _and_xhl(Z80Cpu* cpu)			MCR_AND_XHL
Z80FN _and_a(Z80Cpu* cpu)			MCR_AND(R_Z80A)				/* !! */
Z80FN _xor_b(Z80Cpu* cpu)			MCR_XOR(R_Z80B)
Z80FN _xor_c(Z80Cpu* cpu)			MCR_XOR(R_Z80C)
Z80FN _xor_d(Z80Cpu* cpu)			MCR_XOR(R_Z80D)
Z80FN _xor_e(Z80Cpu* cpu)			MCR_XOR(R_Z80E)
Z80FN _xor_h(Z80Cpu* cpu)			MCR_XOR(R_Z80H)
Z80FN _xor_l(Z80Cpu* cpu)			MCR_XOR(R_Z80L)
Z80FN _xor_xhl(Z80Cpu* cpu)			MCR_XOR_XHL
Z80FN _xor_a(Z80Cpu* cpu)			MCR_XOR(R_Z80A)				/* !! */

Z80FN _or_b(Z80Cpu* cpu)			MCR_OR(R_Z80B)
Z80FN _or_c(Z80Cpu* cpu)			MCR_OR(R_Z80C)
Z80FN _or_d(Z80Cpu* cpu)			MCR_OR(R_Z80D)
Z80FN _or_e(Z80Cpu* cpu)			MCR_OR(R_Z80E)
Z80FN _or_h(Z80Cpu* cpu)			MCR_OR(R_Z80H)
Z80FN _or_l(Z80Cpu* cpu)			MCR_OR(R_Z80L)
Z80FN _or_xhl(Z80Cpu* cpu)			MCR_OR_XHL
Z80FN _or_a(Z80Cpu* cpu)			MCR_OR(R_Z80A)				/* !! */
Z80FN _cp_b(Z80Cpu* cpu)			MCR_CP(R_Z80B)
Z80FN _cp_c(Z80Cpu* cpu)			MCR_CP(R_Z80C)
Z80FN _cp_d(Z80Cpu* cpu)			MCR_CP(R_Z80D)
Z80FN _cp_e(Z80Cpu* cpu)			MCR_CP(R_Z80E)
Z80FN _cp_h(Z80Cpu* cpu)			MCR_CP(R_Z80H)
Z80FN _cp_l(Z80Cpu* cpu)			MCR_CP(R_Z80L)
Z80FN _cp_xhl(Z80Cpu* cpu)			MCR_CP_XHL
Z80FN _cp_a(Z80Cpu* cpu)			MCR_CP(R_Z80A)				/* !! */

Z80FN _ret_nz(Z80Cpu* cpu)			MCR_RETNFLG(Z_FLAG)
Z80FN _pop_bc(Z80Cpu* cpu)			MCR_POP(R_Z80BC)
Z80FN _jp_nz(Z80Cpu* cpu)			MCR_JPNFLG(Z_FLAG)
Z80FN _jp(Z80Cpu* cpu)				MCR_JP
Z80FN _call_nz(Z80Cpu* cpu)			MCR_CALLNFLG(Z_FLAG)
Z80FN _push_bc(Z80Cpu* cpu)			MCR_PUSH(R_Z80BC)
Z80FN _add_a_byte(Z80Cpu* cpu)		MCR_ADD_BYTE
Z80FN _rst_00(Z80Cpu* cpu)			MCR_RST(0x00)
Z80FN _ret_z(Z80Cpu* cpu)			MCR_RETFLG(Z_FLAG)
Z80FN _ret(Z80Cpu* cpu)				MCR_RET
Z80FN _jp_z(Z80Cpu* cpu)			MCR_JPFLG(Z_FLAG)
Z80FN _call_z(Z80Cpu* cpu)			MCR_CALLFLG(Z_FLAG)
Z80FN _call(Z80Cpu* cpu)			MCR_CALL
Z80FN _adc_a_byte(Z80Cpu* cpu)		MCR_ADC_BYTE
Z80FN _rst_08(Z80Cpu* cpu)			MCR_RST(0x08)

Z80FN _ret_nc(Z80Cpu* cpu)			MCR_RETNFLG(C_FLAG)
Z80FN _pop_de(Z80Cpu* cpu)			MCR_POP(R_Z80DE)
Z80FN _jp_nc(Z80Cpu* cpu)			MCR_JPNFLG(C_FLAG)
Z80FN _out_byte_a(Z80Cpu* cpu)		MCR_OUT_BYTE
Z80FN _call_nc(Z80Cpu* cpu)			MCR_CALLNFLG(C_FLAG)
Z80FN _push_de(Z80Cpu* cpu)			MCR_PUSH(R_Z80DE)
Z80FN _sub_byte(Z80Cpu* cpu)		MCR_SUB_BYTE
Z80FN _rst_10(Z80Cpu* cpu)			MCR_RST(0x10)
Z80FN _ret_c(Z80Cpu* cpu)			MCR_RETFLG(C_FLAG)
Z80FN _exx(Z80Cpu* cpu)				MCR_EXX
Z80FN _jp_c(Z80Cpu* cpu)			MCR_JPFLG(C_FLAG)
Z80FN _in_a_byte(Z80Cpu* cpu)		MCR_IN_BYTE
Z80FN _call_c(Z80Cpu* cpu)			MCR_CALLFLG(C_FLAG)
Z80FN _sbc_a_byte(Z80Cpu* cpu)		MCR_SBC_BYTE
Z80FN _rst_18(Z80Cpu* cpu)			MCR_RST(0x18)

Z80FN _ret_po(Z80Cpu* cpu)			MCR_RETNFLG(V_FLAG)
Z80FN _pop_hl(Z80Cpu* cpu)			MCR_POP(R_Z80HL)
Z80FN _jp_po(Z80Cpu* cpu)			MCR_JPNFLG(V_FLAG)
Z80FN _ex_xsp_hl(Z80Cpu* cpu)		MCR_EX_XSP(R_Z80HL)
Z80FN _call_po(Z80Cpu* cpu)			MCR_CALLNFLG(V_FLAG)
Z80FN _push_hl(Z80Cpu* cpu)			MCR_PUSH(R_Z80HL)
Z80FN _and_byte(Z80Cpu* cpu)		MCR_AND_BYTE
Z80FN _rst_20(Z80Cpu* cpu)			MCR_RST(0x20)
Z80FN _ret_pe(Z80Cpu* cpu)			MCR_RETFLG(V_FLAG)
Z80FN _jp_hl(Z80Cpu* cpu)			MCR_LD_W(R_Z80PC, R_Z80HL)
Z80FN _jp_pe(Z80Cpu* cpu)			MCR_JPFLG(V_FLAG)
Z80FN _ex_de_hl(Z80Cpu* cpu)		MCR_EX(R_Z80DE, R_Z80HL)
Z80FN _call_pe(Z80Cpu* cpu)			MCR_CALLFLG(V_FLAG)
Z80FN _xor_byte(Z80Cpu* cpu)		MCR_XOR_BYTE
Z80FN _rst_28(Z80Cpu* cpu)			MCR_RST(0x28)

Z80FN _ret_p(Z80Cpu* cpu)			MCR_RETNFLG(S_FLAG)
Z80FN _pop_af(Z80Cpu* cpu)			MCR_POP(R_Z80AF)
Z80FN _jp_p(Z80Cpu* cpu)			MCR_JPNFLG(S_FLAG)
Z80FN _di(Z80Cpu* cpu)				MCR_DI
Z80FN _call_p(Z80Cpu* cpu)			MCR_CALLNFLG(S_FLAG)
Z80FN _push_af(Z80Cpu* cpu)			MCR_PUSH(R_Z80AF)
Z80FN _or_byte(Z80Cpu* cpu)			MCR_OR_BYTE
Z80FN _rst_30(Z80Cpu* cpu)			MCR_RST(0x30)
Z80FN _ret_m(Z80Cpu* cpu)			MCR_RETFLG(S_FLAG)
Z80FN _ld_sp_hl(Z80Cpu* cpu)		MCR_LD_W(R_Z80SP, R_Z80HL)
Z80FN _jp_m(Z80Cpu* cpu)			MCR_JPFLG(S_FLAG)
Z80FN _ei(Z80Cpu* cpu)				MCR_EI
Z80FN _call_m(Z80Cpu* cpu)			MCR_CALLFLG(S_FLAG)
Z80FN _cp_byte(Z80Cpu* cpu)			MCR_CP_BYTE
Z80FN _rst_38(Z80Cpu* cpu)			MCR_RST(0x38)


const Z80OP z80c_mainop[256] = {
	_ld_nop,		_ld_bc_word,	_ld_xbc_a,		_inc_bc,		/* 00 */
	_inc_b,			_dec_b,			_ld_b_byte,		_rlca,
	_ex_af_af,		_add_hl_bc,		_ld_a_xbc,		_dec_bc,
	_inc_c,			_dec_c,			_ld_c_byte,		_rrca,

	_djnz,			_ld_de_word,	_ld_xde_a,		_inc_de,		/* 10 */
	_inc_d,			_dec_d,			_ld_d_byte,		_rla,
	_jr,			_add_hl_de,		_ld_a_xde,		_dec_de,
	_inc_e,			_dec_e,			_ld_e_byte,		_rra,

	_jr_nz,			_ld_hl_word,	_ld_xword_hl,	_inc_hl,		/* 20 */
	_inc_h,			_dec_h,			_ld_h_byte,		_daa,
	_jr_z,			_add_hl_hl,		_ld_hl_xword,	_dec_hl,
	_inc_l,			_dec_l,			_ld_l_byte,		_cpl,

	_jr_nc,			_ld_sp_word,	_ld_xbyte_a,	_inc_sp,		/* 30 */
	_inc_xhl,		_dec_xhl,		_ld_xhl_byte,	_scf,
	_jr_c,			_add_hl_sp,		_ld_a_xbyte,	_dec_sp,
	_inc_a,			_dec_a,			_ld_a_byte,		_ccf,

	_ld_nop,		_ld_b_c,		_ld_b_d,		_ld_b_e,		/* 40 */
	_ld_b_h,		_ld_b_l,		_ld_b_xhl,		_ld_b_a,
	_ld_c_b,		_ld_nop,		_ld_c_d,		_ld_c_e,
	_ld_c_h,		_ld_c_l,		_ld_c_xhl,		_ld_c_a,

	_ld_d_b,		_ld_d_c,		_ld_nop,		_ld_d_e,		/* 50 */
	_ld_d_h,		_ld_d_l,		_ld_d_xhl,		_ld_d_a,
	_ld_e_b,		_ld_e_c,		_ld_e_d,		_ld_nop,
	_ld_e_h,		_ld_e_l,		_ld_e_xhl,		_ld_e_a,

	_ld_h_b,		_ld_h_c,		_ld_h_d,		_ld_h_e,		/* 60 */
	_ld_nop,		_ld_h_l,		_ld_h_xhl,		_ld_h_a,
	_ld_l_b,		_ld_l_c,		_ld_l_d,		_ld_l_e,
	_ld_l_h,		_ld_nop,		_ld_l_xhl,		_ld_l_a,

	_ld_xhl_b,		_ld_xhl_c,		_ld_xhl_d,		_ld_xhl_e,		/* 70 */
	_ld_xhl_h,		_ld_xhl_l,		_halt,			_ld_xhl_a,
	_ld_a_b,		_ld_a_c,		_ld_a_d,		_ld_a_e,
	_ld_a_h,		_ld_a_l,		_ld_a_xhl,		_ld_nop,

	_add_a_b,		_add_a_c,		_add_a_d,		_add_a_e,		/* 80 */
	_add_a_h,		_add_a_l,		_add_a_xhl,		_add_a_a,
	_adc_a_b,		_adc_a_c,		_adc_a_d,		_adc_a_e,
	_adc_a_h,		_adc_a_l,		_adc_a_xhl,		_adc_a_a,

	_sub_b,			_sub_c,			_sub_d,			_sub_e,			/* 90 */
	_sub_h,			_sub_l,			_sub_xhl,		_sub_a,
	_sbc_a_b,		_sbc_a_c,		_sbc_a_d,		_sbc_a_e,
	_sbc_a_h,		_sbc_a_l,		_sbc_a_xhl,		_sbc_a_a,

	_and_b,			_and_c,			_and_d,			_and_e,			/* a0 */
	_and_h,			_and_l,			_and_xhl,		_and_a,
	_xor_b,			_xor_c,			_xor_d,			_xor_e,
	_xor_h,			_xor_l,			_xor_xhl,		_xor_a,

	_or_b,			_or_c,			_or_d,			_or_e,			/* b0 */
	_or_h,			_or_l,			_or_xhl,		_or_a,
	_cp_b,			_cp_c,			_cp_d,			_cp_e,
	_cp_h,			_cp_l,			_cp_xhl,		_cp_a,

	_ret_nz,		_pop_bc,		_jp_nz,			_jp,			/* c0 */
	_call_nz,		_push_bc,		_add_a_byte,	_rst_00,
	_ret_z,			_ret,			_jp_z,			z80c_cb,
	_call_z,		_call,			_adc_a_byte,	_rst_08,

	_ret_nc,		_pop_de,		_jp_nc,			_out_byte_a,	/* d0 */
	_call_nc,		_push_de,		_sub_byte,		_rst_10,
	_ret_c,			_exx,			_jp_c,			_in_a_byte,
	_call_c,		z80c_ix,		_sbc_a_byte,	_rst_18,

	_ret_po,		_pop_hl,		_jp_po,			_ex_xsp_hl,		/* e0 */
	_call_po,		_push_hl,		_and_byte,		_rst_20,
	_ret_pe,		_jp_hl,			_jp_pe,			_ex_de_hl,
	_call_pe,		z80c_sub,		_xor_byte,		_rst_28,

	_ret_p,			_pop_af,		_jp_p,			_di,			/* f0 */
	_call_p,		_push_af,		_or_byte,		_rst_30,
	_ret_m,			_ld_sp_hl,		_jp_m,			_ei,
	_call_m,		z80c_iy,		_cp_byte,		_rst_38
};

