/**
 * @file	z80ctc.cpp
 * @brief	Z80 CTC �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "z80ctc.h"
#include <algorithm>
#include <limits.h>

/**
 * �R���X�g���N�^
 */
Z80Ctc::Z80Ctc()
{
	Reset();
}

/**
 * ���Z�b�g
 */
void Z80Ctc::Reset()
{
	m_cVector = 0;
	for (UINT i = 0; i < _countof(m_ch); i++)
	{
		m_ch[i].Reset();
	}
}

/**
 * OUT
 * @param[in] nAddress �A�h���X
 * @param[in] cData �f�[�^
 */
void Z80Ctc::Out(UINT nAddress, REG8 cData)
{
	const UINT nIndex = nAddress & 3;
	if ((!m_ch[nIndex].Write(cData)) && (nIndex == 0))
	{
		m_cVector = cData & 0xf8;
	}
}

/**
 * IN
 * @param[in] nAddress �A�h���X
 * @return �f�[�^
 */
REG8 Z80Ctc::In(UINT nAddress) const
{
	const UINT nIndex = nAddress & 3;
	const Channel& ch = m_ch[nIndex];
	if (nIndex != 3)
	{
		return ch.cCount;
	}
	else
	{
		return (ch.nCounter >> ch.cScale);
	}
}

/**
 * ���̊��荞�݂܂ł̃T�C�N���𓾂�
 * @return �T�C�N��
 */
UINT Z80Ctc::RemainCycle() const
{
	UINT nCycle = UINT_MAX;

	for (UINT i = 0; i < 3; i++)
	{
		const Channel& ch = m_ch[i];
		if ((ch.cCommand & 0x82) == 0x80)
		{
			nCycle = (std::min)(nCycle, ch.nCounter);
		}
	}

	if ((m_ch[3].cCommand & 0x82) == 0x80)
	{
		if (!(m_ch[3].cCommand & 0x40))
		{
			nCycle = (std::min)(nCycle, m_ch[3].nCounter);
		}
		else if (!(m_ch[0].cCommand & 0x02))
		{
			const UINT nCount = ((m_ch[3].nCounter - 1) * m_ch[0].nCountMax) + m_ch[0].nCounter;
			nCycle = (std::min)(nCycle, nCount);
		}
	}
	return nCycle;
}

/**
 * ���s
 * @param[in] nCycle �T�C�N��
 * @return ���荞�݃t���O
 */
REG8 Z80Ctc::Execute(UINT nCycle)
{
	REG8 cInterrupt = 0;

	UINT nCounter = m_ch[0].Execute(nCycle);
	if ((nCounter) && (m_ch[0].cCommand & 0x80))
	{
		cInterrupt |= 0x01;
	}

	if ((m_ch[1].Execute(nCycle)) && (m_ch[1].cCommand & 0x80))
	{
		cInterrupt |= 0x02;
	}

	if ((m_ch[2].Execute(nCycle)) && (m_ch[2].cCommand & 0x80))
	{
		cInterrupt |= 0x04;
	}

	if (!(m_ch[3].cCommand & 0x40))
	{
		nCounter = nCycle;
	}
	if ((m_ch[3].Execute(nCounter)) && (m_ch[3].cCommand & 0x80))
	{
		cInterrupt |= 0x08;
	}
	return cInterrupt;
}

/**
 * ���Z�b�g
 */
void Z80Ctc::Channel::Reset()
{
	this->cCommand = 0x23;
	this->cScale = 8;
	this->cCount = 0;
	this->nCounter = 256 << 8;
	this->nCountMax = 256 << 8;
}

/**
 * ���C�g
 * @param[in] cData �f�[�^
 * @retval true ������
 * @retval false ������
 */
bool Z80Ctc::Channel::Write(REG8 cData)
{
	if (this->cCommand & 0x04)
	{
		this->cCount = cData;
		UINT counter = ((cData - 1) & 0xff) + 1;
		UINT8 scale = 0;
		if (!(this->cCommand & 0x40))
		{
			if (this->cCommand & 0x20)
			{
				scale = 8;
			}
			else
			{
				scale = 4;
			}
		}
		this->cScale = scale;
		this->nCounter = counter << scale;
		this->nCountMax = counter << scale;
		this->cCommand &= ~6;
		return true;
	}
	else if (cData & 1)
	{
		this->cCommand = cData;
		return true;
	}
	else
	{
		return false;
	}
}

/**
 * ���s
 * @param[in] nCycle �T�C�N��
 * @return ���荞�݉�
 */
UINT Z80Ctc::Channel::Execute(UINT nCycle)
{
	UINT nInterrupt = 0;

	if (!(this->cCommand & 0x02))
	{
		if (this->nCounter > nCycle)
		{
			this->nCounter -= nCycle;
		}
		else
		{
			nCycle -= this->nCounter;
			this->nCounter = this->nCountMax - (nCycle % this->nCountMax);
			nInterrupt = (nCycle / this->nCountMax) + 1;
		}
	}
	return nInterrupt;
}
