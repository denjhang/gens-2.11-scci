/**
 * @file	mmapfile.cpp
 * @brief	メモリ マップト ファイル クラスの動作の定義を行います
 */

#include "stdafx.h"
#include "mmapfile.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

/**
 * コンストラクタ
 */
CMMapFile::CMMapFile()
	: m_fd(-1)
	, m_ptr(0)
	, m_size(0)
{
}

/**
 * デストラクタ
 */
CMMapFile::~CMMapFile()
{
	Close();
}

/**
 * ファイル オープン
 * @param[in] filename ファイル名
 * @retval true 成功
 * @retval false 失敗
 */
bool CMMapFile::Open(const char* filename)
{
	Close();

	// in file open
	m_fd = open(filename, O_RDONLY);
	if (m_fd < 0)
	{
		return false;
	}

	// get input file size
	struct stat s;
	::fstat(m_fd, &s);
	const size_t size = s.st_size;

	// mapping input file to memory
	m_ptr = ::mmap(0, size, PROT_READ, MAP_SHARED, m_fd, 0);
	if (!m_ptr)
	{
		Close();
		return false;
	}
	m_size = size;
	return true;
}

/**
 * ファイル クローズ
 */
void CMMapFile::Close()
{
	if (m_ptr)
	{
		::munmap(m_ptr, m_size);
		m_ptr = 0;
		m_size = 0;
	}
	if (m_fd >= 0)
	{
		::close(m_fd);
		m_fd = -1;
	}
}
