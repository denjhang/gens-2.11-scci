/**
 * @file	tickcounter.cpp
 * @brief	TICK カウンタの動作の定義を行います
 */

#include "stdafx.h"
#include "tickcounter.h"
#include <sys/time.h>

/**
 * TICK を得る
 * @return TICK
 */
UINT TickCounter::Get()
{
	struct timeval tv;
	::gettimeofday(&tv, 0);
	return static_cast<UINT>((tv.tv_usec / 1000) + (tv.tv_sec * 1000));
}

/**
 * Delay
 * @param[in] ms ミリ秒
 */
void TickCounter::Delay(UINT ms)
{
	::usleep(ms * 1000);
}
