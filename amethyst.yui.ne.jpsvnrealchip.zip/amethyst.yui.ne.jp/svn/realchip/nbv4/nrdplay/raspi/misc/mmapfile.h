/**
 * @file	mmapfile.h
 * @brief	メモリ マップト ファイル クラスの宣言およびインターフェイスの定義をします
 */

#pragma once

/**
 * @brief メモリ マップト ファイル クラス
 */
class CMMapFile
{
public:
	CMMapFile();
	~CMMapFile();
	bool Open(const char* file);
	void Close();
	void* GetPtr() const;
	size_t GetSize() const;

protected:
	int m_fd;			//!< ファイル ハンドル
	void* m_ptr;		//!< メモリ マップト ポインタ
	size_t m_size;		//!< メモリ マップト サイズ
};

/**
 * ポインタを返す
 * @return ポインタ
 */
inline void* CMMapFile::GetPtr() const
{
	return m_ptr;
}

/**
 * サイズを返す
 * @return サイズ
 */
inline size_t CMMapFile::GetSize() const
{
	return m_size;
}
