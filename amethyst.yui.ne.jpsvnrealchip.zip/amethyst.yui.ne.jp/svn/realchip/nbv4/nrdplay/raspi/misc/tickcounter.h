/**
 * @file	tickcounter.h
 * @brief	TICK カウンタの宣言およびインターフェイスの定義をします
 */

#pragma once

/**
 * @brief TICK カウンター クラス
 */
class TickCounter
{
public:
	static UINT Get();
	static void Delay(UINT ms);
};
