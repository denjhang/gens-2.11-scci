/**
 * @file	main.cpp
 * @brief	nrdplay main
 */

#include "stdafx.h"
#include <iostream>
#include <signal.h>
#include "../nrdplay.h"

/*! アボート フラグ */
bool s_bAbort = false;

/**
 * シグナル ハンドラ
 * @param[in] シグナル タイプ
 */
static void sigintcatch(int sig)
{
	s_bAbort = true;
}

/**
 * メイン
 * @param[in] argc 引数
 * @param[in] argv 引数
 * @return リザルト コード
 */
int main(int argc, const char * argv[])
{
	if (argc < 2)
	{
		std::cerr << "Usage: nrdplay *.nrd" << std::endl;
		return 2;
	}

	signal(SIGINT, sigintcatch);

	NrdPlay play;
	return play.Execute(argv[1], &s_bAbort);
}
