/**
 * @file	externalchipmanager.cpp
 * @brief	外部チップ管理クラスの動作の定義を行います
 */

#include "stdafx.h"
#include "externalchipmanager.h"
#include <algorithm>
#include "nbv4chip.h"
#include <wiringPi.h>
#include <wiringPiSPI.h>

#define GPIO0	0		/*!< GPIO */
#define A0		(1 << 4)
#define WR		(1 << 5)
#define ICL		(1 << 6)
#define ACTLOW	(NBV4_PSG | NBV4_FM1 | NBV4_FM2 | WR | ICL)		/*! アクティブ ロー */

/*! 唯一のインスタンスです */
CExternalChipManager CExternalChipManager::sm_instance;

/**
 * コンストラクタ
 */
CExternalChipManager::CExternalChipManager()
	: m_bInitialized(false)
	, m_bReseted(false)
{
}

/**
 * デストラクタ
 */
CExternalChipManager::~CExternalChipManager()
{
	Deinitialize();
}

/**
 * 初期化
 */
void CExternalChipManager::Initialize()
{
	::wiringPiSetup();
	::wiringPiSPISetup(0, 8000000);
	::pinMode(GPIO0, OUTPUT);
	::digitalWrite(GPIO0, 0);
	m_bInitialized = true;

	ResetChips();
}

/**
 * 解放
 */
void CExternalChipManager::Deinitialize()
{
	std::vector<CNbv4Chip*>::iterator it = m_chips.begin();
	while (it != m_chips.end())
	{
		CNbv4Chip* pChip = *it;
		it = m_chips.erase(it);

		pChip->Reset();
		delete pChip;
	}
}

/**
 * チップ確保
 * @param[in] nChipType チップ タイプ
 * @param[in] nClock チップ クロック
 * @return インスタンス
 */
IExternalChip* CExternalChipManager::GetInterface(IExternalChip::ChipType nChipType, UINT nClock)
{
	IExternalChip* pChip = NULL;

	if (nChipType == IExternalChip::kYM2151)
	{
		if (pChip == NULL)
		{
			pChip = GetNbv4Interface(NBV4_FM1);
		}
		if (pChip == NULL)
		{
			pChip = GetNbv4Interface(NBV4_FM2);
		}
	}
	else if (nChipType == IExternalChip::kAY8910)
	{
		if (pChip == NULL)
		{
			pChip = GetNbv4Interface(NBV4_PSG);
		}
	}
	return pChip;
}

/**
 * チップ確保
 * @param[in] nType チップ タイプ
 * @return インスタンス
 */
IExternalChip* CExternalChipManager::GetNbv4Interface(UINT nType)
{
	for (std::vector<CNbv4Chip*>::iterator it = m_chips.begin(); it != m_chips.end(); ++it)
	{
		if ((*it)->GetType() == nType)
		{
			return NULL;
		}
	}

	CNbv4Chip* pChip = new CNbv4Chip(this, nType);
	m_chips.push_back(pChip);
	return pChip;
}

/**
 * チップ解放
 * @param[in] pChip チップ
 */
void CExternalChipManager::Release(IExternalChip* pChip)
{
	Detach(pChip);
	if (pChip)
	{
		pChip->Reset();
		delete pChip;
	}
}

/**
 * チップ解放
 * @param[in] pChip チップ
 */
void CExternalChipManager::Detach(IExternalChip* pChip)
{
	std::vector<CNbv4Chip*>::iterator it = std::find(m_chips.begin(), m_chips.end(), pChip);
	if (it != m_chips.end())
	{
		m_chips.erase(it);
	}
}

/**
 * 音源リセット
 */
void CExternalChipManager::Reset()
{
	for (std::vector<CNbv4Chip*>::iterator it = m_chips.begin(); it != m_chips.end(); ++it)
	{
		(*it)->Reset();
	}
}

/**
 * チップ リセット
 */
void CExternalChipManager::ResetChips()
{
	if ((m_bInitialized) && (!m_bReseted))
	{
		m_bReseted = true;

		Write(ACTLOW & (~(A0 | ICL)));
		delayMicroseconds(100);
		Write(ACTLOW & (~(A0)));
	}
}

/**
 * レジスタ ライト
 * @param[in] nType タイプ
 * @param[in] nAddr アドレス
 * @param[in] cData データ
 */
void CExternalChipManager::SetRegister(UINT nType, UINT nAddr, UINT8 cData)
{
	if (m_bInitialized)
	{
		WriteData((nAddr << 8) | ((nAddr >> 1) & 0x80), nType);
		WriteData((static_cast<UINT>(cData) << 8) | ((nAddr >> 1) & 0x80) | A0, nType);
		m_bReseted = false;
	}
}

/**
 * データ ライト
 * @param[in] nData データ
 * @param[in] nType タイプ
 */
void CExternalChipManager::WriteData(UINT nData, UINT nType)
{
	Write(nData | ACTLOW);
	Write(nData | (ACTLOW & (~(nType | WR))));
	Write(nData | ACTLOW);
}

/**
 * データ ライト
 * @param[in] nData データ
 */
void CExternalChipManager::Write(UINT nData)
{
	::digitalWrite(GPIO0, 0);

	/* ライト */
	unsigned char buf[2];
	buf[0] = static_cast<unsigned char>(nData >> 0);
	buf[1] = static_cast<unsigned char>(nData >> 8);
	::wiringPiSPIDataRW(0, &buf[0], 2);

	/* ラッチ */
	::digitalWrite(GPIO0, 1);
}
