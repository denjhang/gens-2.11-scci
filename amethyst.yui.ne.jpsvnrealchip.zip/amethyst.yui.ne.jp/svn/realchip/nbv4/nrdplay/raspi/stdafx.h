// stdafx.h : 標準のシステム インクルード ファイル、
//            または参照回数が多く、かつあまり変更されない
//            プロジェクト専用のインクルード ファイルを記述します。
//

#ifndef nrdplay_stdafx_pch
#define nrdplay_stdafx_pch

#define BYTESEX_LITTLE

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

typedef signed int		SINT;			/*!< SINT */
typedef signed char		SINT8;			/*!< SINT8 */
typedef signed int		SINT32;			/*!< SINT32 */
typedef unsigned int	UINT;			/*!< UINT */
typedef unsigned char	UINT8;			/*!< UINT8 */
typedef unsigned short	UINT16;			/*!< UINT16 */
typedef unsigned int	UINT32;			/*!< UINT32 */

typedef const char*		LPCTSTR;		/*!< LPCTSTR */
#define TEXT(x)			x

typedef unsigned int	REG8;
typedef unsigned int	REG16;

#ifndef _countof
//! countof
#define _countof(x)		(sizeof((x)) / sizeof((x)[0]))
#endif	// _countof

#endif	/* nrdplay_stdafx_pch */
