/**
 * @file	soundinterface.cpp
 * @brief	SoundInterface �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundinterface.h"
#include "soundchip/soundchip.h"

/**
 * Constructor
 */
CSoundInterface::CSoundInterface()
	: m_dwDelay(0)
{
	memset(&m_info, 0, sizeof(m_info));
}

/**
 * Destructor
 */
CSoundInterface::~CSoundInterface()
{
	reset();

	while (!m_chips.empty())
	{
		CSoundChip* pChip = m_chips.back();
		m_chips.pop_back();
		delete pChip;
	}
}

/**
 * Checks supported low level API
 * @retval TRUE If supported
 * @retval FALSE If not supported
 */
BOOL __stdcall CSoundInterface::isSupportLowLevelApi()
{
	return FALSE;
}

/**
 * Sends data to the interface
 * @param[in] pData The pointer of the buffer
 * @param[in] dSendDataLen The size of the buffer
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterface::setData(BYTE* pData, DWORD dSendDataLen)
{
	return FALSE;
}

/**
 * Gets data from the interface
 * @param[out] pData The pointer of the buffer
 * @param[in] dGetDataLen The size of the buffer
 * @return The size of received
 */
DWORD __stdcall CSoundInterface::getData(BYTE* pData, DWORD dGetDataLen)
{
	return 0;
}

/**
 * Sets delay time
 * @param[in] dMSec delay time
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterface::setDelay(DWORD dMSec)
{
	return FALSE;
}

/**
 * Gets delay time
 * @return delay time
 */
DWORD __stdcall CSoundInterface::getDelay()
{
	return m_dwDelay;
}

/**
 * reset interfaces(A sound chips initialize after interface reset)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterface::reset()
{
	for (std::vector<CSoundChip*>::iterator it = m_chips.begin(); it != m_chips.end(); ++it)
	{
		(*it)->OnReset();
	}
	return FALSE;
}

/**
 * initialize sound chips
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterface::init()
{
	BOOL r = TRUE;
	for (std::vector<CSoundChip*>::iterator it = m_chips.begin(); it != m_chips.end(); ++it)
	{
		if (!(*it)->init())
		{
			r = FALSE;
		}
	}
	return r;
}

/**
 * Get the count of chips
 * @return The count of chips
 */
DWORD __stdcall CSoundInterface::getSoundChipCount()
{
	return static_cast<DWORD>(m_chips.size());
}

/**
 * Get the instance
 * @param[in] dNum The index of chips
 * @return The instance
 */
SoundChip* __stdcall CSoundInterface::getSoundChip(DWORD dNum)
{
	if (dNum < m_chips.size())
	{
		return m_chips[dNum];
	}
	else
	{
		return NULL;
	}
}
