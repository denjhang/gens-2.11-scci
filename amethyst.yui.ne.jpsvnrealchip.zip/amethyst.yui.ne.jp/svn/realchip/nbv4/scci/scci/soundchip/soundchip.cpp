/**
 * @file	soundchip.cpp
 * @brief	SoundChip �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundchip.h"
#include "soundchipym2151.h"
#include "soundchipym2413.h"
#include "soundchipymz294.h"
#include "scci/SCCIDefines.h"
#include "soundinterface.h"

/**
 * Constructor
 * @param[in] pSoundInterface The instance of CSoundInterface
 * @param[in] info The information of chip
 */
CSoundChip::CSoundChip(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info)
	: m_pSoundInterface(pSoundInterface)
	, m_info(info)
{
	SetBitWidth(8);
}

/**
 * Destructor
 */
CSoundChip::~CSoundChip()
{
}

/**
 * get sound chip information
 * @return The information of the chip
 */
SCCI_SOUND_CHIP_INFO* __stdcall CSoundChip::getSoundChipInfo()
{
	return &m_info;
}

/**
 * get sound chip type
 * @return The type of the chip
 */
int __stdcall CSoundChip::getSoundChipType()
{
	return m_info.iSoundChip;
}

/**
 * Register data
 * @param[in] dAddr The address
 * @param[in] dData The data
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundChip::setRegister(DWORD dAddr, DWORD dData)
{
	const DWORD dwIndex = dAddr & m_nAddressMask;
	if (dwIndex < m_reg.size())
	{
		if (!IsValidData(dwIndex, dData))
		{
			return TRUE;
		}
		m_reg[dwIndex] = dData;
	}
	return m_pSoundInterface->OnWriteRegister(m_info.dBusID, dAddr, dData);
}

/**
 * get Register data(It may not be supported)
 * @param[in] dAddr The address
 * @return The data
 */
DWORD __stdcall CSoundChip::getRegister(DWORD dAddr)
{
//	return getWrittenRegisterData(dAddr);
	return static_cast<DWORD>(-1);
}

/**
 * initialize sound chip(clear registers)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundChip::init()
{
	return FALSE;
}

/**
 * get sound chip clock
 * @return The clock of the chip
 */
DWORD __stdcall CSoundChip::getSoundChipClock()
{
	return m_info.dClock;
}

/**
 * get writed register data
 * @param[in] addr The address
 * @return The data
 */
DWORD __stdcall CSoundChip::getWrittenRegisterData(DWORD addr)
{
	const size_t nIndex = addr & m_nAddressMask;
	if (nIndex < m_reg.size())
	{
		return m_reg[nIndex];
	}
	else
	{
		return static_cast<DWORD>(-1);
	}
}

/**
 * buffer check
 * @retval TRUE If empty
 * @retval FALSE If not empty
 */
BOOL __stdcall CSoundChip::isBufferEmpty()
{
	return TRUE;
}

/**
 * �r�b�g����ݒ�
 * @param[in] nWidth �r�b�g��
 */
void CSoundChip::SetBitWidth(UINT nWidth)
{
	const UINT nSize = 1 << nWidth;
	m_nAddressMask = nSize - 1;
	m_reg.resize(nSize);
	OnReset();
}

/**
 * ���Z�b�g
 */
void CSoundChip::OnReset()
{
	::memset(&m_reg.at(0), 0xff, m_reg.size() * sizeof(DWORD));
}

/**
 * �L���ȃp�����[�^?
 * @param[in] dAddr �A�h���X
 * @param[in] dData �f�[�^
 * @retval true �L��
 * @retval false ����
 */
bool CSoundChip::IsValidData(DWORD dAddr, DWORD dData)
{
	return true;
}

/**
 * �C���X�^���X�̍쐬
 * @param[in] pSoundInterface The instance of CSoundInterface
 * @param[in] info The information of chip
 * @return �C���X�^���X
 */
CSoundChip* CSoundChip::CreateInstance(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info)
{
	switch (info.iSoundChip)
	{
		case SC_TYPE_YM2151:
			return new CSoundChipYm2151(pSoundInterface, info);

		case SC_TYPE_YM2413:
			return new CSoundChipYm2413(pSoundInterface, info);

		case SC_TYPE_YMZ294:
			return new CSoundChipYmz294(pSoundInterface, info);

		default:
			return new CSoundChip(pSoundInterface, info);
	}
}
