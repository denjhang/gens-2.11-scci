/**
 * @file	soundchipym2151.cpp
 * @brief	SoundChip YM2151 �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundchipym2151.h"

/**
 * Constructor
 * @param[in] pSoundInterface The instance of CSoundInterface
 * @param[in] info The information of chip
 */
CSoundChipYm2151::CSoundChipYm2151(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info)
	: CSoundChip(pSoundInterface, info)
{
}

/**
 * Destructor
 */
CSoundChipYm2151::~CSoundChipYm2151()
{
}

/**
 * initialize sound chip(clear registers)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundChipYm2151::init()
{
	for (UINT i = 0; i < 8; i++)
	{
		setRegister(0x08, i);
	}
	for (UINT i = 0xe0; i < 0x100; i++)
	{
		setRegister(i, 0xff);
	}

	return TRUE;
}

/**
 * �L���ȃp�����[�^?
 * @param[in] dAddr �A�h���X
 * @param[in] dData �f�[�^
 * @retval true �L��
 * @retval false ����
 */
bool CSoundChipYm2151::IsValidData(DWORD dAddr, DWORD dData)
{
	return (m_reg[dAddr] != dData);
}
