/**
 * @file	soundchipymz294.cpp
 * @brief	SoundChip YMZ294 �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundchipymz294.h"

/**
 * Constructor
 * @param[in] pSoundInterface The instance of CSoundInterface
 * @param[in] info The information of chip
 */
CSoundChipYmz294::CSoundChipYmz294(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info)
	: CSoundChip(pSoundInterface, info)
{
}

/**
 * Destructor
 */
CSoundChipYmz294::~CSoundChipYmz294()
{
}

/**
 * initialize sound chip(clear registers)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundChipYmz294::init()
{
	setRegister(0x07, 0xff);
	return TRUE;
}

/**
 * �L���ȃp�����[�^?
 * @param[in] dAddr �A�h���X
 * @param[in] dData �f�[�^
 * @retval true �L��
 * @retval false ����
 */
bool CSoundChipYmz294::IsValidData(DWORD dAddr, DWORD dData)
{
	return (dAddr < 14) && (m_reg[dAddr] != dData);
}
