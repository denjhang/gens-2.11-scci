/**
 * @file	soundchipym2413.cpp
 * @brief	SoundChip YM2413 �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundchipym2413.h"

/**
 * Constructor
 * @param[in] pSoundInterface The instance of CSoundInterface
 * @param[in] info The information of chip
 */
CSoundChipYm2413::CSoundChipYm2413(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info)
	: CSoundChip(pSoundInterface, info)
{
}

/**
 * Destructor
 */
CSoundChipYm2413::~CSoundChipYm2413()
{
}

/**
 * initialize sound chip(clear registers)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundChipYm2413::init()
{
	setRegister(0x0e, 0x00);
	for (UINT i = 0; i < 9; i++)
	{
		setRegister(0x30 + i, 0x0f);
		setRegister(0x20 + i, 0x00);
	}
	return TRUE;
}

/**
 * �L���ȃp�����[�^?
 * @param[in] dAddr �A�h���X
 * @param[in] dData �f�[�^
 * @retval true �L��
 * @retval false ����
 */
bool CSoundChipYm2413::IsValidData(DWORD dAddr, DWORD dData)
{
	return (dAddr < 0x40) && (m_reg[dAddr] != dData);
}
