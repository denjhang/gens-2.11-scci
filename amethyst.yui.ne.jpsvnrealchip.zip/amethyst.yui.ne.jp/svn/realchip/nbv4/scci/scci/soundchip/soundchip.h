/**
 * @file	soundchip.h
 * @brief	SoundChip �N���X�̐錾����уC���^�[�t�F�C�X�̒�`�����܂�
 */

#pragma once

#include <vector>
#include "scci/scci.h"

class CSoundInterface;

/**
 * @brief SoundChip �N���X
 */
class CSoundChip : public SoundChip
{
public:
	static CSoundChip* CreateInstance(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info);

	CSoundChip(CSoundInterface* pSoundInterface, const SCCI_SOUND_CHIP_INFO& info);
	virtual ~CSoundChip();

	// get sound chip information
	virtual SCCI_SOUND_CHIP_INFO* __stdcall getSoundChipInfo();
	// get sound chip type
	virtual int __stdcall getSoundChipType();
	// set Register data
	virtual BOOL __stdcall setRegister(DWORD dAddr, DWORD dData);
	// get Register data(It may not be supported)
	virtual DWORD __stdcall getRegister(DWORD dAddr);
	// initialize sound chip(clear registers)
	virtual BOOL __stdcall init();
	// get sound chip clock
	virtual DWORD __stdcall getSoundChipClock();
	// get writed register data
	virtual DWORD __stdcall getWrittenRegisterData(DWORD addr);
	// buffer check
	virtual BOOL __stdcall isBufferEmpty();

	virtual void OnReset();

protected:
	CSoundInterface* m_pSoundInterface;			/*!< �C���^�[�t�F�C�X */
	SCCI_SOUND_CHIP_INFO m_info;				/*!< �`�b�v��� */
	DWORD m_nAddressMask;						/*!< �A�h���X �}�X�N */
	std::vector<DWORD> m_reg;					/*!< ���W�X�^ */

	void SetBitWidth(UINT nWidth);
	virtual bool IsValidData(DWORD dAddr, DWORD dData);
};
