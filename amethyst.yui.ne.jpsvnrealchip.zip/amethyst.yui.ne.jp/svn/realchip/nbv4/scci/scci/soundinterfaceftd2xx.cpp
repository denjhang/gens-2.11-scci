/**
 * @file	soundinterfaceftd2xx.cpp
 * @brief	SoundInterface ftd2xx �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundinterfaceftd2xx.h"
#include <algorithm>
#include "misc/mutex.h"
#include "soundchip/soundchip.h"

/**
 * �R���g���[�� �r�b�g
 */
enum
{
	NBV4_SSG	= (1 << 1),		/*!< SSG */
	NBV4_FM1	= (1 << 2),		/*!< FM1 */
	NBV4_FM2	= (1 << 3),		/*!< FM2 */
	NBV4_A0		= (1 << 4),		/*!< A0 */
	NBV4_WR		= (1 << 5),		/*!< WR */
	NBV4_ICL	= (1 << 6),		/*!< ICL */
	NBV4_A1		= (1 << 7),		/*!< A1 */
	NBV4_ACTLOW	= (NBV4_SSG | NBV4_FM1 | NBV4_FM2 | NBV4_WR | NBV4_ICL)		/*! �A�N�e�B�u ���[ */
};

/**
 * Constructor
 * @param[in] ini �ݒ�
 */
CSoundInterfaceFtd2xx::CSoundInterfaceFtd2xx(const Nbv4Ini& ini)
	: m_ini(ini)
	, m_cLastData(0xff)
	, m_nAddrWaitCount(0)
	, m_nDataWaitCount(0)
{
	ZeroMemory(&m_info, sizeof(m_info));
	Acquire();
}

/**
 * �擾
 */
void CSoundInterfaceFtd2xx::Acquire()
{
	UINT nAddrWait = 0;
	UINT nDataWait = 0;

	switch (m_ini.nId)
	{
		case SC_TYPE_NONE:
			return;

		case SC_TYPE_NBV4:
			sprintf(m_info.cInterfaceName, "NBV4(COM%d)", m_ini.nPort);
			nAddrWait = 5;
			nDataWait = 21;
			break;

		case SC_TYPE_AYB02:
			sprintf(m_info.cInterfaceName, "AYB02(COM%d)", m_ini.nPort);
			nAddrWait = 10;
			nDataWait = 60;
			break;

		default:
			sprintf(m_info.cInterfaceName, "COM%d", m_ini.nPort);
			nAddrWait = 5;
			nDataWait = 15;
			break;
	}

	if (m_ini.nAddrWait != static_cast<UINT>(-1))
	{
		nAddrWait = m_ini.nAddrWait;
	}
	if (m_ini.nDataWait != static_cast<UINT>(-1))
	{
		nDataWait = m_ini.nDataWait;
	}
	m_nAddrWaitCount = GetWaitBytes(nAddrWait);
	m_nDataWaitCount = GetWaitBytes(nDataWait);

	FT_STATUS nStatus = m_ft.OpenComPort(m_ini.nPort);
	if (nStatus != FT_OK)
	{
		return;
	}

	m_ft.SetBitMode(0x00, FT_BITMODE_RESET);
	m_ft.SetBitMode(0xff, FT_BITMODE_ASYNC_BITBANG);
	m_ft.SetBaudRate(m_ini.nSpeed);

	if ((m_ini.nId == SC_TYPE_NBV4) || (m_ini.nId == SC_TYPE_AYB02))
	{
		// SSG
		SCCI_SOUND_CHIP_INFO ssg;
		ZeroMemory(&ssg, sizeof(ssg));
		strcpy(ssg.cSoundChipName, "SSG");
		ssg.iSoundChip = SC_TYPE_YMZ294;
		ssg.dClock = m_ini.dClock;
		ssg.iCompatibleSoundChip[0] = SC_TYPE_AY8910;
		ssg.dCompatibleClock[0] = m_ini.dClock / 2;
		ssg.dBusID = 0;
		ssg.dSoundLocation = SC_LOCATION_MONO;
		m_chips.push_back(CSoundChip::CreateInstance(this, ssg));

		// FM
		SCCI_SOUND_CHIP_INFO fm;
		ZeroMemory(&fm, sizeof(fm));
		switch (m_ini.nId)
		{
			case SC_TYPE_NBV4:
				strcpy(fm.cSoundChipName, "OPM");
				fm.iSoundChip = SC_TYPE_YM2151;
				break;

			case SC_TYPE_AYB02:
				strcpy(fm.cSoundChipName, "OPLL");
				fm.iSoundChip = SC_TYPE_YM2413;
				break;
		}
		fm.dClock = m_ini.dClock;
		fm.dSoundLocation = SC_LOCATION_STEREO;
		for (UINT i = 0; i < 2; i++)
		{
			fm.dBusID = i + 1;
			m_chips.push_back(CSoundChip::CreateInstance(this, fm));
		}
	}
	else
	{
		// FM
		SCCI_SOUND_CHIP_INFO fm;
		ZeroMemory(&fm, sizeof(fm));
		strcpy(fm.cSoundChipName, "FM");
		fm.iSoundChip = m_ini.nId;
		fm.dClock = m_ini.dClock;
		fm.dSoundLocation = SC_LOCATION_STEREO;
		fm.dBusID = 0;
		m_chips.push_back(CSoundChip::CreateInstance(this, fm));
	}

	// info
	m_info.iSoundChipCount = static_cast<int>(m_chips.size());

	Start();
}

/**
 * �E�F�C�g�l���Z�o����
 * @param[in] ns �E�F�C�g
 * @return �E�F�C�g�l
 */
UINT CSoundInterfaceFtd2xx::GetWaitBytes(UINT ns) const
{
	UINT64 nWait = m_ini.nSpeed;
	nWait *= ns;
	nWait += (1000 * 1000 * 10) - 1;
	UINT nBytes = static_cast<UINT>(nWait / (1000 * 1000 * 10));
	if (nBytes)
	{
		nBytes--;
	}
	return nBytes;
}

/**
 * Destructor
 */
CSoundInterfaceFtd2xx::~CSoundInterfaceFtd2xx()
{
	Stop();

	reset();
	while (!m_chips.empty())
	{
		CSoundChip* pChip = m_chips.back();
		m_chips.pop_back();
		delete pChip;
	}

	if (m_ft.IsOpened())
	{
		m_ft.SetBitMode(0x00, FT_BITMODE_RESET);
		m_ft.Close();
	}
}

/**
 * Sets delay time
 * @param[in] dMSec delay time
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceFtd2xx::setDelay(DWORD dMSec)
{
	m_dwDelay = dMSec;
	return TRUE;
}

/**
 * reset interfaces(A sound chips initialize after interface reset)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceFtd2xx::reset()
{
	CSoundInterface::reset();

	m_csBuffer.Enter();
	m_buf.clear();
	m_csBuffer.Leave();

	CMutex m(m_csFtHandle);
	if (!m_ft.IsOpened())
	{
		return FALSE;
	}

	Send(NBV4_ACTLOW & (~NBV4_ICL));
	m_tick.Delay(1);
	Send(NBV4_ACTLOW);

	return TRUE;
}

/**
 * ���M
 * @param[in] nData �f�[�^
 */
void CSoundInterfaceFtd2xx::Send(UINT nData)
{
	std::vector<unsigned char> buffer;
	AddData(buffer, nData);
	m_ft.Write(&buffer.at(0), static_cast<DWORD>(buffer.size()));
}

/**
 * ���W�X�^��������
 * @param[in] dBusID �o�X ID
 * @param[in] dAddr �A�h���X
 * @param[in] dData �f�[�^
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL CSoundInterfaceFtd2xx::OnWriteRegister(DWORD dBusID, DWORD dAddr, DWORD dData)
{
	if (!m_ft.IsOpened())
	{
		return FALSE;
	}

	m_csBuffer.Enter();

	if (m_ini.nBufferSize)
	{
		while (m_buf.size() >= m_ini.nBufferSize)
		{
			m_csBuffer.Leave();
			::Sleep(1);
			m_csBuffer.Enter();
		}
	}

	Command cmd;
	cmd.nTimestamp = m_tick.Get() + m_dwDelay;
	cmd.cBus = static_cast<unsigned char>(dBusID);
	cmd.cAddress = static_cast<unsigned short>(dAddr);
	cmd.cData = static_cast<unsigned char>(dData);
	m_buf.push_back(cmd);

	m_csBuffer.Leave();
	return TRUE;
}

/**
 * �^�X�N
 * @retval true �p��
 */
bool CSoundInterfaceFtd2xx::Task()
{
	std::vector<unsigned char> buffer;

	m_csBuffer.Enter();
	while (!m_buf.empty())
	{
		const Command& cmd = m_buf.front();
		if (static_cast<INT>(cmd.nTimestamp - m_tick.Get()) > 0)
		{
			break;
		}

		if (!buffer.empty())
		{
			buffer.insert(buffer.end(), m_nDataWaitCount, m_cLastData);
		}

		// �A�h���X
		const UINT nType = (NBV4_ACTLOW & (~(NBV4_SSG << cmd.cBus))) | ((cmd.cAddress & 0x100) ? NBV4_A1 : 0);
		AddCommand(buffer, nType | (cmd.cAddress << 8));

		buffer.insert(buffer.end(), m_nAddrWaitCount, m_cLastData);

		// �f�[�^
		AddCommand(buffer, nType | NBV4_A0 | (cmd.cData << 8));

		m_buf.pop_front();
	}
	m_csBuffer.Leave();

	if (buffer.empty())
	{
		m_tick.Delay(1);
		return true;
	}

	CMutex m(m_csFtHandle);
	if (m_ft.IsOpened())
	{
		m_ft.Write(&buffer.at(0), static_cast<DWORD>(buffer.size()));
	}
	return true;
}

/**
 * �R�}���h�ǉ�
 * @param[in,out] buffer �f�[�^ �o�b�t�@
 * @param[in] nData �f�[�^
 */
void CSoundInterfaceFtd2xx::AddCommand(std::vector<unsigned char>& buffer, UINT nData)
{
	AddData(buffer, nData);
	AddData(buffer, nData & (~NBV4_WR));
	AddData(buffer, nData);
}

/**
 * �f�[�^�ǉ�
 * @param[in,out] buffer �f�[�^ �o�b�t�@
 * @param[in] nData �f�[�^
 */
void CSoundInterfaceFtd2xx::AddData(std::vector<unsigned char>& buffer, UINT nData)
{
	unsigned char data = m_cLastData;

	data &= ~m_ini.RBit;
	buffer.push_back(data);

	for (UINT i = 0; i < 8; i++)
	{
		data &= ~(m_ini.SBit | m_ini.DBit | m_ini.CBit);
		if (nData & (0x0080 >> i))
		{
			data |= m_ini.CBit;
		}
		if (nData & (0x8000 >> i))
		{
			data |= m_ini.DBit;
		}
		buffer.push_back(data);

		data |= m_ini.SBit;
		buffer.push_back(data);
	}

	data |= m_ini.RBit;
	buffer.push_back(data);

	m_cLastData = data;
}
