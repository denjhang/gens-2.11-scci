/**
 * @file	soundinterfacemanager.cpp
 * @brief	SoundInterfaceManager �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "soundinterfacemanager.h"
#include <algorithm>
#include "soundinterface.h"
#include "soundinterfaceftd2xx.h"
#include "config/configDlg.h"
#include "misc/inifile.h"
#include "scci/SCCIDefines.h"
#include "soundchip/soundchip.h"

//! Singleton instance
CSoundInterfaceManager CSoundInterfaceManager::sm_instance;

//! �o�[�W����
#define SCCI_MAJOR_VERSION		0		/*!< Major */
#define SCCI_MINOR_VERSION		3		/*!< Minor */

/**
 * Constructor
 */
CSoundInterfaceManager::CSoundInterfaceManager()
	: m_dwDelay(0)
{
}

/**
 * Destructor
 */
CSoundInterfaceManager::~CSoundInterfaceManager()
{
	releaseInstance();
}

/**
 * Get the count of interfaces
 * @return The count of interfaces
 */
int __stdcall CSoundInterfaceManager::getInterfaceCount()
{
	return static_cast<int>(m_interfaces.size());
}

/**
 * Get the information of the interface
 * @param[in] iInterfaceNo The index of interfaces
 * @return The information
 */
SCCI_INTERFACE_INFO* __stdcall CSoundInterfaceManager::getInterfaceInfo(int iInterfaceNo)
{
	if (static_cast<size_t>(iInterfaceNo) < m_interfaces.size())
	{
		return m_interfaces[iInterfaceNo]->getSoundInterfaceInfo();
	}
	else
	{
		return NULL;
	}
}

/**
 * Gets interface instance
 * @param[in] iInterfaceNo The index of interfaces
 * @return The instance
 */
SoundInterface* __stdcall CSoundInterfaceManager::getInterface(int iInterfaceNo)
{
	if (static_cast<size_t>(iInterfaceNo) < m_interfaces.size())
	{
		return m_interfaces[iInterfaceNo];
	}
	else
	{
		return NULL;
	}
}

/**
 * Releases the sound interface
 * @param[in] pSoundInterface The instance of the sound interface
 * @retval TRUE If succeeded
 * @retval FALSE If failed
 */
BOOL __stdcall CSoundInterfaceManager::releaseInterface(SoundInterface* pSoundInterface)
{
	std::vector<CSoundInterface*>::iterator it = std::find(m_interfaces.begin(), m_interfaces.end(), pSoundInterface);
	if (it != m_interfaces.end())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/**
 * Releases all interfaces
 * @retval TRUE If succeeded
 * @retval FALSE If failed
 */
BOOL __stdcall CSoundInterfaceManager::releaseAllInterface()
{
	return TRUE;
}

/**
 * Gets sound chip instance
 * @param[in] iSoundChipType The type of the chip
 * @param[in] dClock The clock of the chip
 * @return The interface
 */
SoundChip* __stdcall CSoundInterfaceManager::getSoundChip(int iSoundChipType, DWORD dClock)
{
	if ((iSoundChipType == SC_TYPE_NONE) || (dClock == 0))
	{
		return NULL;
	}

	for (std::vector<CSoundInterface*>::iterator it = m_interfaces.begin(); it != m_interfaces.end(); ++it)
	{
		CSoundInterface* pSoundInterface = *it;

		const DWORD nCount = pSoundInterface->getSoundChipCount();
		for (DWORD i = 0; i < nCount; i++)
		{
			SoundChip* pSoundChip = pSoundInterface->getSoundChip(i);
			SCCI_SOUND_CHIP_INFO* pInfo = pSoundChip->getSoundChipInfo();
			if (pInfo->bIsUsed)
			{
				continue;
			}

			if ((pInfo->iSoundChip == iSoundChipType) && (pInfo->dClock == dClock))
			{
				pInfo->bIsUsed = TRUE;
				return pSoundChip;
			}
			for (UINT j = 0; j < 2; j++)
			{
				if ((pInfo->iCompatibleSoundChip[j] == iSoundChipType) && (pInfo->dCompatibleClock[j] == dClock))
				{
					pInfo->bIsUsed = TRUE;
					return pSoundChip;
				}
			}
		}
	}
	return NULL;
}

/**
 * release sound chip instance
 * @param[in] pSoundChip The instance of chip
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::releaseSoundChip(SoundChip* pSoundChip)
{
	BOOL r = FALSE;
	if (pSoundChip)
	{
		SCCI_SOUND_CHIP_INFO* pInfo = pSoundChip->getSoundChipInfo();
		r = pInfo->bIsUsed;
		pInfo->bIsUsed = FALSE;
	}
	return r;
}

/**
 * release all sound chip instance
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::releaseAllSoundChip()
{
	for (std::vector<CSoundInterface*>::iterator it = m_interfaces.begin(); it != m_interfaces.end(); ++it)
	{
		CSoundInterface* pSoundInterface = *it;

		const DWORD nCount = pSoundInterface->getSoundChipCount();
		for (DWORD i = 0; i < nCount; i++)
		{
			releaseSoundChip(pSoundInterface->getSoundChip(i));
		}
	}
	return TRUE;
}

/**
 * Sets delay time
 * @param[in] dMSec delay time
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::setDelay(DWORD dMSec)
{
	m_dwDelay = dMSec;

	BOOL r = TRUE;
	for (std::vector<CSoundInterface*>::iterator it = m_interfaces.begin(); it != m_interfaces.end(); ++it)
	{
		if (!(*it)->setDelay(dMSec))
		{
			r = FALSE;
		}
	}
	return r;
}

/**
 * Gets delay time
 * @return delay time
 */
DWORD __stdcall CSoundInterfaceManager::getDelay()
{
	return m_dwDelay;
}

/**
 * reset interfaces(A sound chips initialize after interface reset)
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::reset()
{
	BOOL r = TRUE;
	for (std::vector<CSoundInterface*>::iterator it = m_interfaces.begin(); it != m_interfaces.end(); ++it)
	{
		if (!(*it)->reset())
		{
			r = FALSE;
		}
	}
	return r;
}

/**
 * initialize sound chips
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::init()
{
	BOOL r = TRUE;
	for (std::vector<CSoundInterface*>::iterator it = m_interfaces.begin(); it != m_interfaces.end(); ++it)
	{
		if (!(*it)->init())
		{
			r = FALSE;
		}
	}
	return r;
}

/**
 * Sound Interface instance initialize
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::initializeInstance()
{
	if (!m_interfaces.empty())
	{
		return FALSE;
	}

	CIniFile file;
	m_dwDelay = file.GetInt(TEXT("scci"), TEXT("DelayTime"), 100);

	std::vector<std::tstring> sections;
	file.GetSections(sections);
	for (std::vector<std::tstring>::const_iterator it = sections.begin(); it != sections.end(); ++it)
	{
		CSoundInterface* pSoundInterface = NULL;

		const LONG nPort = Nbv4Ini::GetPortFromName(*it);
		if (nPort > 0)
		{
			Nbv4Ini ini(nPort);
			ini.Read(file);
			pSoundInterface = new CSoundInterfaceFtd2xx(ini);
		}
		if (pSoundInterface)
		{
			if (pSoundInterface->getSoundChipCount())
			{
				pSoundInterface->setDelay(m_dwDelay);
				m_interfaces.push_back(pSoundInterface);
			}
			else
			{
				delete pSoundInterface;
			}
		}
	}

	return m_interfaces.empty() ? FALSE : TRUE;
}

/**
 * Sound Interface instance release
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::releaseInstance()
{
	while (!m_interfaces.empty())
	{
		CSoundInterface* pInterface = m_interfaces.back();
		m_interfaces.pop_back();
		delete pInterface;
	}
	return TRUE;
}

/**
 * Configure
 * @retval true If succeeded
 * @retval false If failed
 */
BOOL __stdcall CSoundInterfaceManager::config()
{
	CConfigDlg dlg;
	dlg.DoModal();
	return TRUE;
}

/**
 * get version info
 * @param[out] pMVersion The minor of the version
 * @return The major of the version
 */
DWORD __stdcall CSoundInterfaceManager::getVersion(DWORD *pMVersion)
{
	if (pMVersion)
	{
		*pMVersion = SCCI_MINOR_VERSION;
	}
	return SCCI_MAJOR_VERSION;
}

/**
 * get Level mater disp valid
 * @retval TRUE If valid
 * @retval FALSE If invalid
 */
BOOL __stdcall CSoundInterfaceManager::isValidLevelDisp()
{
	return FALSE;
}

/**
 * ���[�^�[�\����?
 * @retval TRUE If visiabled
 * @retval FALSE If not visiabled
 */
BOOL __stdcall CSoundInterfaceManager::isLevelDisp()
{
	return FALSE;
}

/**
 * ���[�^�\��
 * @param[in] bDisp The flags of the disaplay
 */
void __stdcall CSoundInterfaceManager::setLevelDisp(BOOL bDisp)
{
}

/**
 * Sets mode
 * @param[in] iMode The mode
 */
void __stdcall CSoundInterfaceManager::setMode(int iMode)
{
}

/**
 * Sends data
 */
void __stdcall CSoundInterfaceManager::sendData()
{
}

/**
 * Clears buffer
 */
void __stdcall CSoundInterfaceManager::clearBuff()
{
}

/**
 * set Acquisition Mode(Sound Chip)
 * @param[in] iMode The mode
 */
void __stdcall CSoundInterfaceManager::setAcquisitionMode(int iMode)
{
}

/**
 * set Acquisition Mode clock renge
 * @param[in] dClock The clock
 */
void __stdcall CSoundInterfaceManager::setAcquisitionModeClockRenge(DWORD dClock)
{
}

/**
 * Sets command buffer size
 * @param[in] dBuffSize The size of the buffer
 * @retval TRUE If succeeded
 * @retval FALSE If failed
 */
BOOL __stdcall CSoundInterfaceManager::setCommandBuffetSize(DWORD dBuffSize)
{
	return FALSE;
}

/**
 * Checks buffer
 * @retval TRUE If empty
 * @retval FALSE If not empty
 */
BOOL __stdcall CSoundInterfaceManager::isBufferEmpty()
{
	return TRUE;
}
