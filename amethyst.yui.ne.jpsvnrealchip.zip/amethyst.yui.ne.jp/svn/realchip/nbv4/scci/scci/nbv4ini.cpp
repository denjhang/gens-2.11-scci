/**
 * @file	nbv4setupDlg.cpp
 * @brief	NBV4 �Z�b�g�A�b�v �_�C�A���O �N���X�̓���̒�`���s���܂�
 */

#include "stdafx.h"
#include "nbv4ini.h"
#include "misc/inifile.h"

/**
 * ���O����|�[�g�ԍ��𓾂�
 * @param[in] name ���O
 * @return �|�[�g�ԍ�
 */
LONG Nbv4Ini::GetPortFromName(const std::tstring& name)
{
	if (name.find(TEXT("ftd2xx(COM")) != 0)
	{
		return 0;
	}
	return _ttol(name.c_str() + 10);
}

/**
 * ������
 * @param[in] p �|�[�g�ԍ�
 */
Nbv4Ini::Nbv4Ini(LONG p)
	: nPort(p)
	, nSpeed(115200)
	, nBufferSize(512)
	, nId(SC_TYPE_NONE)
	, dClock(SC_CLOCK_NONE)
	, SBit(0x01)
	, DBit(0x02)
	, CBit(0x04)
	, RBit(0x08)
	, nAddrWait(static_cast<UINT>(-1))
	, nDataWait(static_cast<UINT>(-1))
{
}

/**
 * ���O�𓾂�
 * @return ���O
 */
std::tstring Nbv4Ini::Name() const
{
	TCHAR szName[64];
	::wsprintf(szName, TEXT("ftd2xx(COM%d)"), this->nPort);
	return std::tstring(szName);
}

/**
 * �ǂݍ���
 * @param[in] ini �C���X�^���X
 */
void Nbv4Ini::Read(CIniFile& ini)
{
	const std::tstring rSection = Name();
	this->nSpeed = ini.GetInt(rSection.c_str(), TEXT("Speed"), this->nSpeed);
	this->nBufferSize = ini.GetInt(rSection.c_str(), TEXT("BufferSize"), this->nBufferSize);
	this->nId = static_cast<SC_CHIP_TYPE>(ini.GetInt(rSection.c_str(), TEXT("SLOT_00_CHIP_ID"), this->nId));
	this->dClock = ini.GetInt(rSection.c_str(), TEXT("SLOT_00_CHIP_CLOCK"), this->dClock);

	this->SBit = ini.GetInt(rSection.c_str(), TEXT("SBit"), this->SBit);
	this->DBit = ini.GetInt(rSection.c_str(), TEXT("DBit"), this->DBit);
	this->CBit = ini.GetInt(rSection.c_str(), TEXT("CBit"), this->CBit);
	this->RBit = ini.GetInt(rSection.c_str(), TEXT("RBit"), this->RBit);
	this->nAddrWait = ini.GetInt(rSection.c_str(), TEXT("AddrWait"), this->nAddrWait);
	this->nDataWait = ini.GetInt(rSection.c_str(), TEXT("DataWait"), this->nDataWait);
}

/**
 * ��������
 * @param[in] ini �C���X�^���X
 */
void Nbv4Ini::Write(CIniFile& ini) const
{
	const std::tstring rSection = Name();
	ini.WriteInt(rSection.c_str(), TEXT("Speed"), this->nSpeed);
	ini.WriteInt(rSection.c_str(), TEXT("SLOT_00_CHIP_ID"), this->nId);
	ini.WriteInt(rSection.c_str(), TEXT("SLOT_00_CHIP_CLOCK"), this->dClock);
}
