#ifndef _S_CRC32_H
#define _S_CRC32_H

unsigned long crc32(unsigned long crc, const unsigned char *buf, unsigned int len);

#endif
