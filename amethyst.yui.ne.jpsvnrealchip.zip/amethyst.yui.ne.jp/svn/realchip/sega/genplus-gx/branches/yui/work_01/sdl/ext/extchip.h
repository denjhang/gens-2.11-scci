/**
 * @file	extchip.h
 * @brief	SCCI ���t�N���X�̐錾����уC���^�[�t�F�C�X�̒�`�����܂�
 */

#pragma once

#ifdef __cplusplus

class CExternalOpna;
class CExternalChipEvent;
class CExternalDcsg;

/**
 * @brief �O���`�b�v �N���X
 */
class CExtChip
{
public:
	static CExtChip* GetInstance();

	CExtChip();
	~CExtChip();
	void Initialize();
	void Uninitialize();
	void Reset();
	void WriteOpn2(unsigned int nAddress, unsigned char cData);
	void WriteOpll(unsigned int nAddress, unsigned char cData);
	void WriteDcsg(unsigned char cData);
	void Mute(bool bMute);
	bool HasOpll() const;
	static void Sync();
	static void AddCycles(unsigned int mc68kcycles, unsigned int z80cycles);

private:
	static CExtChip sm_instance;		//!< �C���X�^���X
	CExternalOpna* m_pOpn2;				//!< OPN2
	CExternalChipEvent* m_pOpll;		//!< OPLL
	CExternalDcsg* m_pDcsg;				//!< DCSG
};

/**
 * �C���X�^���X���擾
 * @return �C���X�^���X
 */
inline CExtChip* CExtChip::GetInstance()
{
	return &sm_instance;
}

inline bool CExtChip::HasOpll() const
{
	return (m_pOpll != NULL);
}

extern "C"
{

#endif

void extchip_initialize(void);
void extchip_uninitialize(void);
void extchip_reset(void);
void extchip_mute(int bMute);
void extchip_writeopn2(unsigned int nAddress, unsigned char cData);
void extchip_writeopll(unsigned char cAddress, unsigned char cData);
void extchip_writedcsg(unsigned char cData);
int extchip_isenabledopll(void);
void extchip_sync(void);
void extchip_update(unsigned int cycles);

#ifdef __cplusplus
}
#endif
