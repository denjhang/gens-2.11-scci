/**
 * @file	pciport.cpp
 * @brief	Implementation of the port functions
 */

#include "stdafx.h"

/**
 * I/O �ǂݏo�� (BYTE)
 * @param[in] ulAddress �A�h���X
 * @return �f�[�^
 */
UCHAR WINAPI _IoReadChar(ULONG ulAddress)
{
	UCHAR ucData;
	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_READ_PORT_UCHAR, &ulAddress, sizeof(ulAddress), &ucData, sizeof(ucData));
	return ucData;
}

/**
 * I/O �ǂݏo�� (WORD)
 * @param[in] ulAddress �A�h���X
 * @return �f�[�^
 */
USHORT WINAPI _IoReadShort(ULONG ulAddress)
{
	USHORT usData;
	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_READ_PORT_USHORT, &ulAddress, sizeof(ulAddress), &usData, sizeof(usData));
	return usData;
}

/**
 * I/O �ǂݏo�� (DWORD)
 * @param[in] ulAddress �A�h���X
 * @return �f�[�^
 */
ULONG WINAPI _IoReadLong(ULONG ulAddress)
{
	ULONG ulData;
	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_READ_PORT_ULONG, &ulAddress, sizeof(ulAddress), &ulData, sizeof(ulData));
	return ulData;
}

/**
 * I/O �������� (BYTE)
 * @param[in] ulAddress �A�h���X
 * @param[in] ucData �f�[�^
 */
void WINAPI _IoWriteChar(ULONG ulAddress, UCHAR ucData)
{
	PCIDEBUG_WRITEPORT param;
	param.PortNumber = ulAddress;
	param.CharData[0] = ucData;
	const ULONG ulParam = static_cast<ULONG>(offsetof(PCIDEBUG_WRITEPORT, CharData[1]));

	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_WRITE_PORT_UCHAR, &param, ulParam);
}

/**
 * I/O �������� (WORD)
 * @param[in] ulAddress �A�h���X
 * @param[in] usData �f�[�^
 */
void WINAPI _IoWriteShort(ULONG ulAddress, USHORT usData)
{
	PCIDEBUG_WRITEPORT param;
	param.PortNumber = ulAddress;
	param.ShortData[0] = usData;
	const ULONG ulParam = static_cast<ULONG>(offsetof(PCIDEBUG_WRITEPORT, ShortData[1]));

	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_WRITE_PORT_USHORT, &param, ulParam);
}

/**
 * I/O �������� (DWORD)
 * @param[in] ulAddress �A�h���X
 * @param[in] ulData �f�[�^
 */
void WINAPI _IoWriteLong(ULONG ulAddress, ULONG ulData)
{
	PCIDEBUG_WRITEPORT param;
	param.PortNumber = ulAddress;
	param.LongData[0] = ulData;
	const ULONG ulParam = static_cast<ULONG>(offsetof(PCIDEBUG_WRITEPORT, LongData[1]));

	CDriver::GetInstance()->DeviceIoControl(IOCTL_PCI_WRITE_PORT_ULONG, &param, ulParam);
}
