/**
 * @file	pcifunc.cpp
 * @brief	Implementation of the extend functions
 */

#include "stdafx.h"

extern BOOL pciConfigRead(ULONG ulPciAddress, ULONG ulRegAddress, LPVOID lpData, ULONG ulData);

/**
 * �o�X���𓾂�
 * @return �o�X��
 */
ULONG WINAPI _pciBusNumber(void)
{
	ULONG bus = 0;
	while (bus < NumberOfBus)
	{
		const ULONG ulPciAddress = pciBusDevFunc(bus, 0, 0);

		ULONG id;
		if ((!pciConfigRead(ulPciAddress, 0x00, &id, sizeof(id))) && (GetLastError() == PCI_ERR_BUSNOTEXIST))
		{
			break;
		}
		bus++;
	}
	return bus;
}

/**
 * �f�o�C�X����
 * @param[in] ulVenderId �x���_�[ ID
 * @param[in] ulDeviceId �f�o�C�X ID
 * @param[in] ulIndex �C���f�b�N�X
 * @return �A�h���X
 */
ULONG WINAPI _pciFindPciDevice(ULONG ulVenderId, ULONG ulDeviceId, ULONG ulIndex)
{
	ulVenderId &= 0xffff;
	if (ulVenderId == 0xffff)
	{
		return 0x83;
	}

	const ULONG ulTargetId = (ulDeviceId << 16) | ulVenderId;

	for (ULONG bus = 0; bus < NumberOfBus; bus++)
	{
		for (ULONG dev = 0; dev < NumberOfDevice; dev++)
		{
			bool bMultiFunction = false;
			for (ULONG func = 0; func < NumberOfFunc; func++)
			{
				const ULONG ulPciAddress = pciBusDevFunc(bus, dev, func);

				ULONG id;
				if (pciConfigRead(ulPciAddress, 0x00, &id, sizeof(id)))
				{
					if (func == 0)
					{
						// ���@�\�f�o�C�X�����ׂ�
						UCHAR type;
						if (pciConfigRead(ulPciAddress, 0x0e, &type, sizeof(type)))
						{
							bMultiFunction = ((type & 0x80) != 0);
						}
					}

					if (id == ulTargetId)
					{
						if (ulIndex == 0)
						{
							return (ulPciAddress << 16);
						}
						ulIndex--;
					}
				}
				else if (GetLastError() == PCI_ERR_BUSNOTEXIST)
				{
					return 0x86;
				}

				if (!bMultiFunction)
				{
					break;
				}
			}
		}
	}
	return 0x86;
}

/**
 * �f�o�C�X����
 * @param[in] ucBaseClass �x�[�X �N���X
 * @param[in] ucSubClass �T�u �N���X
 * @param[in] ucProgramInterface �v���O���� �C���^�[�t�F�[�X
 * @param[in] ulIndex �C���f�b�N�X
 * @return �A�h���X
 */
ULONG WINAPI _pciFindPciClass(UCHAR ucBaseClass, UCHAR ucSubClass, UCHAR ucProgramInterface, ULONG ulIndex)
{
	const ULONG ulTargetClass = (ucBaseClass << 16) | (ucSubClass << 8) | ucProgramInterface;

	ULONG count = 0;
	for (ULONG bus = 0; bus < NumberOfBus; bus++)
	{
		for (ULONG dev = 0; dev < NumberOfDevice; dev++)
		{
			bool bMultiFunction = false;
			for (ULONG func = 0; func < NumberOfFunc; func++)
			{
				const ULONG ulPciAddress = pciBusDevFunc(bus, dev, func);

				ULONG conf[3];
				if (pciConfigRead(ulPciAddress, 0x00, conf, sizeof(conf)))
				{
					if (func == 0)
					{
						// ���@�\�f�o�C�X�����ׂ�
						UCHAR type;
						if (pciConfigRead(ulPciAddress, 0x0e, &type, sizeof(type)))
						{
							bMultiFunction = ((type & 0x80) != 0);
						}
					}
					if ((conf[2] >> 8) == ulTargetClass)
					{
						if (ulIndex == 0)
						{
							return (ulPciAddress << 16);
						}
						ulIndex--;
					}
				}
				else if (GetLastError() == PCI_ERR_BUSNOTEXIST)
				{
					return 0x86;
				}

				if (!bMultiFunction)
				{
					break;
				}
			}
		}
	}
	return 0x86;
}
