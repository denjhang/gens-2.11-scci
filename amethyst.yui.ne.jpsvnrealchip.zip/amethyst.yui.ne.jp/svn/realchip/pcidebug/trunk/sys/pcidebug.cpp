/**
 * @file	pcidebug.cpp
 * @brief	pcidegug.sys windows NT driver part
 *
 * Original: Aug 20 1999 kashiwano masahiro
 */

#include "stddef.h"
#include <ntddk.h>
#include <string.h>
#include <devioctl.h>
#include "pciioctl.h"
#include "pcidebug.h"

// �v���g�^�C�v
static NTSTATUS PciDispatch(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
static VOID PciUnload(IN PDRIVER_OBJECT DriverObject);

//! @brief driver local data structure specific to each device object
struct PciDevice
{
	PDEVICE_OBJECT	_DeviceObject;		//!< The Gpd device object.

	void Initialize(PDEVICE_OBJECT DeviceObject);
	void Deinitialize();
	static NTSTATUS ReadPort(ULONG ulIoctlCode, PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned);
	static NTSTATUS WritePort(ULONG ulIoctlCode, PVOID lpInBuffer, ULONG ulInBuffer);
	static NTSTATUS ReadMem(PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned);
	static NTSTATUS WriteMem(PVOID lpInBuffer, ULONG ulInBuffer);
	static NTSTATUS ReadConf(PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned);
	static NTSTATUS WriteConf(PVOID lpInBuffer, ULONG ulInBuffer);

#ifndef _WIN64
	HANDLE			_Handle;			//!< �n���h��
	PKEVENT			_Event;				//!< �C�x���g
	PKINTERRUPT		_InterruptObject;	//!< ���荞��
	BOOLEAN			_SetupOK;			//!< after call setup interrupt set TRUE
	KAFFINITY		_Affinity;			//!< Affinity mask
	KIRQL			_Irql;				//!< IRQ level
	ULONG			_MappedVector;		//!< �}�b�v�g �x�N�^
	KINTERRUPT_MODE	_InterruptMode;		//!< ���荞�݃��[�h
	BOOLEAN			_ShareVector;		//!< ���L�x�N�^

	NTSTATUS SetupInterrupt(PVOID lpInBuffer, ULONG ulInBuffer);
	NTSTATUS SetupInterrupt(const PCIDEBUG_ISRINFOA& isrinfo);
	NTSTATUS SetupInterrupt(const PCIDEBUG_ISRINFOW& isrinfo);
	NTSTATUS ConnectInterrupt();
	VOID DisconnectInterrupt();
	static BOOLEAN InterruptServiceRoutine(IN PKINTERRUPT Interrupt, IN OUT PVOID Context);
	static VOID DpcRoutine(IN PKDPC Dpc, IN PDEVICE_OBJECT DeviceObject, IN OUT PIRP Irp, IN PVOID Context);
#endif	// _WIN64
};

/**
 * DriverEntry is the first driver-supplied routine that is called after a driver is loaded. It is responsible for initializing the driver.
 * @param[in] DriverObject A pointer to a DRIVER_OBJECT structure that represents the driver's WDM driver object.
 * @param[in] RegistryPath A pointer to a UNICODE_STRING structure that specifies the path to the driver's Parameters key in the registry.
 * @return If the routine succeeds, it must return STATUS_SUCCESS. Otherwise, it must return one of the error status values that are defined in ntstatus.h.
 */
NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING RegistryPath)
{
	DriverObject->MajorFunction[IRP_MJ_CREATE]			= PciDispatch;
	DriverObject->MajorFunction[IRP_MJ_CLOSE]			= PciDispatch;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]	= PciDispatch;
	DriverObject->DriverUnload							= PciUnload;
	DriverObject->DriverStartIo = NULL;

	// �f�o�C�X�쐬
	UNICODE_STRING NtDeviceName;
	RtlInitUnicodeString(&NtDeviceName, PCI_DEVICE_NAME);

	PDEVICE_OBJECT DeviceObject;
	NTSTATUS Status = IoCreateDevice(DriverObject, sizeof(PciDevice), &NtDeviceName, PCI_TYPE, 0, FALSE, &DeviceObject);
	if (!NT_SUCCESS(Status))
	{
		return Status;
	}

	// DOS���o�^
	UNICODE_STRING Win32DeviceName;
	RtlInitUnicodeString(&Win32DeviceName, DOS_DEVICE_NAME);

	Status = IoCreateSymbolicLink(&Win32DeviceName, &NtDeviceName);
	if (!NT_SUCCESS(Status))
	{
		IoDeleteDevice(DeviceObject);
		return Status;
	}

	(static_cast<PciDevice*>(DeviceObject->DeviceExtension))->Initialize(DeviceObject);

	return Status;
}

/**
 * This routine is the dispatch handler for the driver. It is responsible for processing the IRPs.
 * @param[in] DeviceObject Pointer to device object.
 * @param[in] Irp Pointer to the current IRP.
 * @return STATUS_SUCCESS if the IRP was processed successfully, otherwise an error indicating the reason for failure.
 */
static NTSTATUS PciDispatch(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	Irp->IoStatus.Information = 0;

	PIO_STACK_LOCATION pIrpStack = IoGetCurrentIrpStackLocation(Irp);

	NTSTATUS Status = STATUS_NOT_IMPLEMENTED;

	switch (pIrpStack->MajorFunction)
	{
		case IRP_MJ_CREATE:
		case IRP_MJ_CLOSE:
			Status = STATUS_SUCCESS;
			break;

		case IRP_MJ_DEVICE_CONTROL:
			switch (pIrpStack->Parameters.DeviceIoControl.IoControlCode)
			{
				case IOCTL_PCI_READ_PORT_UCHAR:
				case IOCTL_PCI_READ_PORT_USHORT:
				case IOCTL_PCI_READ_PORT_ULONG:
					Status = PciDevice::ReadPort(pIrpStack->Parameters.DeviceIoControl.IoControlCode, Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength, Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.OutputBufferLength, &Irp->IoStatus.Information);
					break;

				case IOCTL_PCI_WRITE_PORT_UCHAR:
				case IOCTL_PCI_WRITE_PORT_USHORT:
				case IOCTL_PCI_WRITE_PORT_ULONG:
					Status = PciDevice::WritePort(pIrpStack->Parameters.DeviceIoControl.IoControlCode, Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength);
					break;

				case IOCTL_PCI_READ_MEM:
					Status = PciDevice::ReadMem(Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength, Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.OutputBufferLength, &Irp->IoStatus.Information);
					break;

				case IOCTL_PCI_WRITE_MEM:
					Status = PciDevice::WriteMem(Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength);
					break;

				case IOCTL_PCI_READ_CONF:
					Status = PciDevice::ReadConf(Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength, Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.OutputBufferLength, &Irp->IoStatus.Information);
					break;

				case IOCTL_PCI_WRITE_CONF:
					Status = PciDevice::WriteConf(Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength);
					break;

#ifndef _WIN64
				case IOCTL_PCI_ENABLEISR:
					Status = (static_cast<PciDevice*>(DeviceObject->DeviceExtension))->ConnectInterrupt();
					break;

				case IOCTL_PCI_SETUPISR:
					Status = (static_cast<PciDevice*>(DeviceObject->DeviceExtension))->SetupInterrupt(Irp->AssociatedIrp.SystemBuffer, pIrpStack->Parameters.DeviceIoControl.InputBufferLength);
					break;
#endif	// _WIN64
			}
			break;
	}

	Irp->IoStatus.Status = Status;

	IoCompleteRequest(Irp, IO_NO_INCREMENT);

	return Status;
}

/**
 * This routine prepares our driver to be unloaded.
 * It is responsible for freeing all resources allocated by DriverEntry as well as any allocated while the driver was running.
 * The symbolic link must be deleted as well.
 * @param[in] DriverObject Pointer to driver object created by the system.
 * @return �Ȃ�
 */
static VOID PciUnload(IN PDRIVER_OBJECT DriverObject)
{
	PciDevice* dev = static_cast<PciDevice*>(DriverObject->DeviceObject->DeviceExtension);

#ifndef _WIN64
	dev->DisconnectInterrupt();
#endif	// _WIN64

	UNICODE_STRING Win32DeviceName;
	RtlInitUnicodeString(&Win32DeviceName, DOS_DEVICE_NAME);

	IoDeleteSymbolicLink(&Win32DeviceName);

	dev->Deinitialize();
}



// ---- PciDevice

/**
 * ������
 * @param[in] DeviceObject Pointer to device object.
 */
void PciDevice::Initialize(PDEVICE_OBJECT DeviceObject)
{
	// �N���A
	RtlZeroMemory(this, sizeof(*this));

	_DeviceObject = DeviceObject;

#ifndef _WIN64
	IoInitializeDpcRequest(DeviceObject, DpcRoutine);
#endif	// _WIN64
}

/**
 * ���
 */
void PciDevice::Deinitialize()
{
#ifndef _WIN64
	if (_Handle)
	{
		ZwClose(_Handle);
		_Handle = NULL;
	}
#endif	// _WIN64

	IoDeleteDevice(_DeviceObject);
}

/**
 * �|�[�g�ǂݍ��� IOCTL
 * @param[in] ulIoctlCode ���s���铮��̐���R�[�h
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpOutBuffer �o�̓f�[�^���󂯎��o�b�t�@�ւ̃|�C���^
 * @param[in] ulOutBuffer �o�̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpBytesReturned �o�C�g�����󂯎��ϐ��ւ̃|�C���^
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::ReadPort(ULONG ulIoctlCode, PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned)
{
	PCIDEBUG_READPORT& param = *(static_cast<PCIDEBUG_READPORT*>(lpInBuffer));
	if (ulInBuffer != sizeof(param))
	{
		return STATUS_INVALID_PARAMETER;
	}

	ULONG ulDataBufferSize = 0;
	switch (ulIoctlCode)
	{
		case IOCTL_PCI_READ_PORT_UCHAR:
			ulDataBufferSize = sizeof(UCHAR);
			break;

		case IOCTL_PCI_READ_PORT_USHORT:
			ulDataBufferSize = sizeof(USHORT);
			break;

		case IOCTL_PCI_READ_PORT_ULONG:
			ulDataBufferSize = sizeof(ULONG);
			break;

		default:
			return STATUS_INVALID_PARAMETER;
	}
	if (ulOutBuffer < ulDataBufferSize)
	{
		return STATUS_INVALID_PARAMETER;
	}

	ULONG_PTR lpPort = param.PortNumber;
	switch (ulIoctlCode)
	{
		case IOCTL_PCI_READ_PORT_UCHAR:
			*(static_cast<PUCHAR>(lpOutBuffer)) = READ_PORT_UCHAR(reinterpret_cast<PUCHAR>(lpPort));
			break;

		case IOCTL_PCI_READ_PORT_USHORT:
			*(static_cast<PUSHORT>(lpOutBuffer)) = READ_PORT_USHORT(reinterpret_cast<PUSHORT>(lpPort));
			break;

		case IOCTL_PCI_READ_PORT_ULONG:
			*(static_cast<PULONG>(lpOutBuffer)) = READ_PORT_ULONG(reinterpret_cast<PULONG>(lpPort));
			break;
	}

	*lpBytesReturned = ulDataBufferSize;

	return STATUS_SUCCESS;
}

/**
 * �|�[�g�������� IOCTL
 * @param[in] ulIoctlCode ���s���铮��̐���R�[�h
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::WritePort(ULONG ulIoctlCode, PVOID lpInBuffer, ULONG ulInBuffer)
{
	ULONG ulInput = 0;
	switch (ulIoctlCode)
	{
		case IOCTL_PCI_WRITE_PORT_UCHAR:
			ulInput = offsetof(PCIDEBUG_WRITEPORT, CharData[1]);
			break;

		case IOCTL_PCI_WRITE_PORT_USHORT:
			ulInput = offsetof(PCIDEBUG_WRITEPORT, ShortData[1]);
			break;

		case IOCTL_PCI_WRITE_PORT_ULONG:
			ulInput = offsetof(PCIDEBUG_WRITEPORT, LongData[1]);
			break;

		default:
			return STATUS_INVALID_PARAMETER;
	}
	if (ulInBuffer < ulInput)
	{
		return STATUS_INVALID_PARAMETER;
	}

	PCIDEBUG_WRITEPORT& param = *(static_cast<PCIDEBUG_WRITEPORT*>(lpInBuffer));
	ULONG_PTR lpPort = param.PortNumber;
	switch (ulIoctlCode)
	{
		case IOCTL_PCI_WRITE_PORT_UCHAR:
			WRITE_PORT_UCHAR(reinterpret_cast<PUCHAR>(lpPort), param.CharData[0]);
			break;

		case IOCTL_PCI_WRITE_PORT_USHORT:
			WRITE_PORT_USHORT(reinterpret_cast<PUSHORT>(lpPort), param.ShortData[0]);
			break;

		case IOCTL_PCI_WRITE_PORT_ULONG:
			WRITE_PORT_ULONG(reinterpret_cast<PULONG>(lpPort), param.LongData[0]);
			break;
	}

	return STATUS_SUCCESS;
}

/**
 * �������ǂݍ��� IOCTL
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpOutBuffer �o�̓f�[�^���󂯎��o�b�t�@�ւ̃|�C���^
 * @param[in] ulOutBuffer �o�̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpBytesReturned �o�C�g�����󂯎��ϐ��ւ̃|�C���^
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::ReadMem(PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned)
{
	const PCIDEBUG_MEM& param = *(static_cast<PCIDEBUG_MEM*>(lpInBuffer));
	if (ulInBuffer != sizeof(param))
	{
		return STATUS_INVALID_PARAMETER;
	}

	const ULONG ulSize = param.UnitSize * param.Count;
	if (ulOutBuffer < ulSize)
	{
		return STATUS_INVALID_PARAMETER;
	}

	PHYSICAL_ADDRESS pa;
	pa.HighPart = 0;
	pa.LowPart = param.Address;
	PVOID mapped = MmMapIoSpace(pa, ulSize, MmNonCached);

	NTSTATUS Status = STATUS_SUCCESS;
	switch (param.UnitSize)
	{
		case sizeof(UCHAR):
			READ_REGISTER_BUFFER_UCHAR(static_cast<PUCHAR>(mapped), static_cast<PUCHAR>(lpOutBuffer), param.Count);
			break;

		case sizeof(USHORT):
			READ_REGISTER_BUFFER_USHORT(static_cast<PUSHORT>(mapped), static_cast<PUSHORT>(lpOutBuffer), param.Count);
			break;

		case sizeof(ULONG):
			READ_REGISTER_BUFFER_ULONG(static_cast<PULONG>(mapped), static_cast<PULONG>(lpOutBuffer), param.Count);
			break;

		default:
			Status = STATUS_INVALID_PARAMETER;
			break;
	}

	MmUnmapIoSpace(mapped, ulSize);

	if (Status == STATUS_SUCCESS)
	{
		*lpBytesReturned = ulOutBuffer;
	}

	return Status;
}

/**
 * �������������� IOCTL
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::WriteMem(PVOID lpInBuffer, ULONG ulInBuffer)
{
	PCIDEBUG_MEM* param = static_cast<PCIDEBUG_MEM*>(lpInBuffer);
	if (ulInBuffer < sizeof(*param))
	{
		return STATUS_INVALID_PARAMETER;
	}

	const ULONG ulSize = param->UnitSize * param->Count;
	if (ulInBuffer < (sizeof(*param) + ulSize))
	{
		return STATUS_INVALID_PARAMETER;
	}

	PHYSICAL_ADDRESS pa;
	pa.HighPart = 0;
	pa.LowPart = param->Address;
	PVOID mapped = MmMapIoSpace(pa, ulSize, MmNonCached);

	NTSTATUS Status = STATUS_SUCCESS;
	switch (param->UnitSize)
	{
		case sizeof(UCHAR):
			WRITE_REGISTER_BUFFER_UCHAR(static_cast<PUCHAR>(mapped), reinterpret_cast<PUCHAR>(param + 1), param->Count);
			break;

		case sizeof(USHORT):
			WRITE_REGISTER_BUFFER_USHORT(static_cast<PUSHORT>(mapped), reinterpret_cast<PUSHORT>(param + 1), param->Count);
			break;

		case sizeof(ULONG):
			WRITE_REGISTER_BUFFER_ULONG(static_cast<PULONG>(mapped), reinterpret_cast<PULONG>(param + 1), param->Count);
			break;

		default:
			Status = STATUS_INVALID_PARAMETER;
			break;
	}

	MmUnmapIoSpace(mapped, ulSize);

	return Status;
}

/**
 * �R���t�B�M���A�[�ǂݍ��� IOCTL
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpOutBuffer �o�̓f�[�^���󂯎��o�b�t�@�ւ̃|�C���^
 * @param[in] ulOutBuffer �o�̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @param[out] lpBytesReturned �o�C�g�����󂯎��ϐ��ւ̃|�C���^
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::ReadConf(PVOID lpInBuffer, ULONG ulInBuffer, PVOID lpOutBuffer, ULONG ulOutBuffer, ULONG_PTR* lpBytesReturned)
{
	const PCIDEBUG_CONF& param = *(static_cast<PCIDEBUG_CONF*>(lpInBuffer));
	if (ulInBuffer != sizeof(param))
	{
		return STATUS_INVALID_PARAMETER;
	}

	const ULONG BusNumber = pciGetBus(param.PciAddress);

	PCI_SLOT_NUMBER slot;
	slot.u.AsULONG = 0;
	slot.u.bits.DeviceNumber = pciGetDev(param.PciAddress);
	slot.u.bits.FunctionNumber = pciGetFunc(param.PciAddress);
	const ULONG ulRet = HalGetBusDataByOffset(PCIConfiguration, BusNumber, slot.u.AsULONG, lpOutBuffer, param.PciOffset, ulOutBuffer);
	if (ulRet == 0)
	{
		return PCI_ERR_BUSNOTEXIST;
	}
	else if (ulRet != ulOutBuffer)
	{
		return (ulRet == 2) ? PCI_ERR_NODEVICE : PCI_ERR_CONFREAD;
	}
	else
	{
		*lpBytesReturned = ulOutBuffer;
		return STATUS_SUCCESS;
	}
}

/**
 * �R���t�B�M���A�[�������� IOCTL
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::WriteConf(PVOID lpInBuffer, ULONG ulInBuffer)
{
	PCIDEBUG_CONF* param = static_cast<PCIDEBUG_CONF*>(lpInBuffer);
	if (ulInBuffer < sizeof(*param))
	{
		return STATUS_INVALID_PARAMETER;
	}

	const ULONG ulWriteSize = ulInBuffer - sizeof(*param);
	const ULONG BusNumber = pciGetBus(param->PciAddress);

	PCI_SLOT_NUMBER slot;
	slot.u.AsULONG = 0;
	slot.u.bits.DeviceNumber = pciGetDev(param->PciAddress);
	slot.u.bits.FunctionNumber = pciGetFunc(param->PciAddress);
	const ULONG ulRet = HalSetBusDataByOffset(PCIConfiguration, BusNumber, slot.u.AsULONG, param + 1, param->PciOffset, ulWriteSize);
	if (ulRet == 0)
	{
		return PCI_ERR_BUSNOTEXIST;
	}
	else if (ulRet != ulWriteSize)
	{
		return (ulRet == 2) ? PCI_ERR_NODEVICE : PCI_ERR_CONFWRITE;
	}
	else
	{
		return STATUS_SUCCESS;
	}
}

#ifndef _WIN64

/**
 * ���荞�݋֎~
 * @return �Ȃ�
 */
VOID PciDevice::DisconnectInterrupt()
{
	if (_InterruptObject)
	{
		IoDisconnectInterrupt(_InterruptObject);
		_InterruptObject = NULL;
	}
}

/**
 * ���荞�ݐݒ�
 * @param[in] lpInBuffer ���̓f�[�^����������o�b�t�@�ւ̃|�C���^
 * @param[in] ulInBuffer ���̓o�b�t�@�̃o�C�g�P�ʂ̃T�C�Y
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::SetupInterrupt(PVOID lpInBuffer, ULONG ulInBuffer)
{
	if (ulInBuffer == sizeof(PCIDEBUG_ISRINFOA))
	{
		return SetupInterrupt(*(static_cast<PCIDEBUG_ISRINFOA*>(lpInBuffer)));
	}
	else if (ulInBuffer == sizeof(PCIDEBUG_ISRINFOW))
	{
		return SetupInterrupt(*(static_cast<PCIDEBUG_ISRINFOW*>(lpInBuffer)));
	}
	else
	{
		return STATUS_INVALID_PARAMETER;
	}
}

/**
 * ���荞�ݐݒ� (ANSI)
 * @param[in] isrinfo ���荞�ݏ��
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::SetupInterrupt(const PCIDEBUG_ISRINFOA& isrinfo)
{
	if (isrinfo.InterfaceType >= MaximumInterfaceType)
	{
		return STATUS_INVALID_PARAMETER;
	}

	// �ȑO�̊��荞�݂��N���A
	DisconnectInterrupt();
	if (_Handle)
	{
		ZwClose(_Handle);
		_Handle = NULL;
	}
	_SetupOK = FALSE;

	if (isrinfo.EventName[0] != '\0')
	{
		// Event��: L"\\BaseNamedObjects\\" + isrinfo.EventName
		UNICODE_STRING EventBase;
		RtlInitUnicodeString(&EventBase, L"\\BaseNamedObjects\\");

		STRING AnsiEventName;
		RtlInitString(&AnsiEventName, isrinfo.EventName);

		UNICODE_STRING EventName;
		RtlAnsiStringToUnicodeString(&EventName, &AnsiEventName, TRUE);

		UNICODE_STRING Name;
		Name.MaximumLength = EventBase.Length + EventName.Length + 1;
		Name.Length = 0;
		Name.Buffer = static_cast<PWCH>(ExAllocatePool(NonPagedPool, Name.MaximumLength * sizeof(WCHAR)));
		RtlZeroMemory(Name.Buffer, Name.MaximumLength * sizeof(WCHAR));

		RtlCopyUnicodeString(&Name, &EventBase);
		RtlAppendUnicodeStringToString(&Name, &EventName);
		RtlFreeUnicodeString(&EventName);

		_Event = IoCreateNotificationEvent(&Name, &_Handle);
		ExFreePool(Name.Buffer);

		if (!_Event)
		{
			return PCI_ERR_EVENTCREATE;
		}
		KeClearEvent(_Event);

		_MappedVector = HalGetInterruptVector(isrinfo.InterfaceType, isrinfo.BusNumber, isrinfo.BusInterruptLevel, isrinfo.BusInterruptVector, &_Irql, &_Affinity);
		_InterruptMode = isrinfo.InterruptMode;
		_ShareVector = isrinfo.ShareVector;

		_SetupOK = TRUE;
	}
	return STATUS_SUCCESS;
}

/**
 * ���荞�ݐݒ� (UNICODE)
 * @param[in] isrinfo ���荞�ݏ��
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::SetupInterrupt(const PCIDEBUG_ISRINFOW& isrinfo)
{
	if (isrinfo.InterfaceType >= MaximumInterfaceType)
	{
		return STATUS_INVALID_PARAMETER;
	}

	// �ȑO�̊��荞�݂��N���A
	DisconnectInterrupt();
	if (_Handle)
	{
		ZwClose(_Handle);
		_Handle = NULL;
	}
	_SetupOK = FALSE;

	if (isrinfo.EventName[0] != '\0')
	{
		// Event��: L"\\BaseNamedObjects\\" + isrinfo.EventName
		UNICODE_STRING EventBase;
		RtlInitUnicodeString(&EventBase, L"\\BaseNamedObjects\\");

		UNICODE_STRING EventName;
		RtlInitUnicodeString(&EventName, isrinfo.EventName);

		UNICODE_STRING Name;
		Name.MaximumLength = EventBase.Length + EventName.Length + 1;
		Name.Length = 0;
		Name.Buffer = static_cast<PWCH>(ExAllocatePool(NonPagedPool, Name.MaximumLength * sizeof(WCHAR)));
		RtlZeroMemory(Name.Buffer, Name.MaximumLength * sizeof(WCHAR));

		RtlCopyUnicodeString(&Name, &EventBase);
		RtlAppendUnicodeStringToString(&Name, &EventName);

		_Event = IoCreateNotificationEvent(&Name, &_Handle);
		ExFreePool(Name.Buffer);

		if (!_Event)
		{
			return PCI_ERR_EVENTCREATE;
		}
		KeClearEvent(_Event);

		_MappedVector = HalGetInterruptVector(isrinfo.InterfaceType, isrinfo.BusNumber, isrinfo.BusInterruptLevel, isrinfo.BusInterruptVector, &_Irql, &_Affinity);
		_InterruptMode = isrinfo.InterruptMode;
		_ShareVector = isrinfo.ShareVector;

		_SetupOK = TRUE;
	}
	return STATUS_SUCCESS;
}

/**
 * ���荞�ݐݒ�
 * @return �X�e�[�^�X �R�[�h
 */
NTSTATUS PciDevice::ConnectInterrupt()
{
	if (!_SetupOK)
	{
		return STATUS_ACCESS_VIOLATION;
	}
	if (_InterruptObject)
	{
		return STATUS_ACCESS_VIOLATION;
	}
	KeClearEvent(_Event);

	NTSTATUS Status = IoConnectInterrupt(&_InterruptObject, InterruptServiceRoutine, _DeviceObject, NULL, _MappedVector, _Irql, _Irql, _InterruptMode, _ShareVector, _Affinity, FALSE);
	if (!NT_SUCCESS(Status))
	{
		KdPrint(("STAT: couldn't connect interrupt\n"));
	}

	return Status;
}

/**
 * ISR
 * @param[in] Interrupt
 * @param[out] Context
 * @retval TRUE ����
 */
BOOLEAN PciDevice::InterruptServiceRoutine(IN PKINTERRUPT Interrupt, IN OUT PVOID Context)
{
	PDEVICE_OBJECT DeviceObject = static_cast<PDEVICE_OBJECT>(Context);

	(static_cast<PciDevice*>(DeviceObject->DeviceExtension))->DisconnectInterrupt();

	IoRequestDpc(DeviceObject, DeviceObject->CurrentIrp, NULL);

	return TRUE;
}

/**
 * This is the deferred procedure call that gets queued by the ISR to finish any interrupt relate processing
 * @param[in] Dpc Caller-supplied pointer to a KDPC structure, which represents the DPC object that is associated with this DpcForIsr routine.
 * @param[in] DeviceObject Caller-supplied pointer to a DEVICE_OBJECT structure. This is the device object for the target device, previously created by the driver's AddDevice routine.
 * @param[in,out] Irp Caller-supplied pointer to an IRP structure that describes the I/O operation.
 * @param[in] Context Caller-supplied pointer to driver-defined context information, specified in a previous call to IoRequestDpc.
 * @return None
 */
VOID PciDevice::DpcRoutine(IN PKDPC Dpc, IN PDEVICE_OBJECT DeviceObject, IN OUT PIRP Irp, IN PVOID Context)
{
	PIRP CurrentIrp = DeviceObject->CurrentIrp;
	if (CurrentIrp)
	{
		CurrentIrp->IoStatus.Information = 0;
		CurrentIrp->IoStatus.Status = STATUS_SUCCESS;

		IoStartNextPacket(DeviceObject, FALSE);
		IoCompleteRequest(CurrentIrp, IO_NO_INCREMENT);
	}

	// �C�x���g���V�O�i����Ԃɂ���
	PciDevice* dev = static_cast<PciDevice*>(DeviceObject->DeviceExtension);
	KeSetEvent(dev->_Event, 0, FALSE);
}
#endif	// _WIN64
