/**
 * @file	pcidef.h
 * @brief	Declaration of pcidebug.dll
 */

#pragma once

#define NumberOfBus		256
#define NumberOfFunc	8
#define NumberOfDevice	32

/* Define the I/O bus interface types. */
typedef enum _INTERFACE_TYPE
{
	InterfaceTypeUndefined = -1,
	Internal,
	Isa,
	Eisa,
	MicroChannel,
	TurboChannel,
	PCIBus,
	VMEBus,
	NuBus,
	PCMCIABus,
	CBus,
	MPIBus,
	MPSABus,
	ProcessorInternal,
	InternalPowerBus,
	PNPISABus,
	PNPBus,
	Vmcs,
	MaximumInterfaceType
} INTERFACE_TYPE, *PINTERFACE_TYPE;

/** Interrupt modes. */
typedef enum _KINTERRUPT_MODE
{
	LevelSensitive,
	Latched
} KINTERRUPT_MODE;
