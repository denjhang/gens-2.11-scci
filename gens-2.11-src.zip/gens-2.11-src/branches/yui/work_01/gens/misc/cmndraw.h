
#ifndef __CMNDRAW
#define __CMNDRAW

#if !defined(RGB16)
#define RGB16		UINT16
#endif

enum
{
	RGB24_B	= 0,
	RGB24_G	= 1,
	RGB24_R	= 2
};

#if !defined(RGB32)
typedef union
{
	UINT32	d;
	struct
	{
		UINT8	b;
		UINT8	g;
		UINT8	r;
		UINT8	e;
	} p;
} RGB32;
#define RGB32D(r, g, b)		(((r) << 16) + ((g) << 8) + ((b) << 0))
#endif

typedef union {
	RGB32	pal32;
	UINT16	pal16;
	UINT8	pal8;
} CMNPAL;

typedef struct {
	UINT8	*ptr;
	int		width;
	int		height;
	int		xalign;
	int		yalign;
	int		bpp;
} CMNVRAM;

typedef void (*CMNPALCNV)(CMNPAL *dst, const RGB32 *src, UINT pals, UINT bpp);

#ifdef __cplusplus
extern "C" {
#endif

void cmndraw_makegrad(RGB32 *pal, int pals, RGB32 bg, RGB32 fg);

void cmndraw_fill(const CMNVRAM *vram, int x, int y,
										int cx, int cy, CMNPAL fg);
void cmndraw_setfg(const CMNVRAM *vram, const UINT8 *src,
										int x, int y, CMNPAL fg);
void cmndraw_setpat(const CMNVRAM *vram, const UINT8 *src,
										int x, int y, CMNPAL bg, CMNPAL fg);
void cmddraw_text8(CMNVRAM *vram, int x, int y, const char *str, CMNPAL fg);

#ifdef __cplusplus
}
#endif

#endif

