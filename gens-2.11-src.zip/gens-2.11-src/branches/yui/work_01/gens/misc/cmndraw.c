#include	"compiler.h"
#include	"cmndraw.h"
#include	"minifont.res"


void cmndraw_makegrad(RGB32 *pal, int pals, RGB32 bg, RGB32 fg) {

	int		i;

	if (pals <= 0) {
		return;
	}
	pals--;
	for (i=0; i<pals; i++) {
		pal[i].p.b = bg.p.b + ((int)(fg.p.b - bg.p.b) * i) / pals;
		pal[i].p.r = bg.p.r + ((int)(fg.p.r - bg.p.r) * i) / pals;
		pal[i].p.g = bg.p.g + ((int)(fg.p.g - bg.p.g) * i) / pals;
		pal[i].p.e = bg.p.e + ((int)(fg.p.e - bg.p.e) * i) / pals;
	}
	pal[i].d = fg.d;
}


/* ---- */

void cmndraw_fill(const CMNVRAM *vram, int x, int y,
										int cx, int cy, CMNPAL fg) {

	UINT8	*p;
	int		dalign;
	int		r;

	if (vram == NULL) {
		return;
	}
	p = vram->ptr + (x * vram->xalign) + (y * vram->yalign);
	dalign = vram->yalign - (vram->xalign * cx);
	switch(vram->bpp) {
#if defined(SUPPORT_8BPP)
		case 8:
			do {
				r = cx;
				do {
					*p = fg.pal8;
					p += vram->xalign;
				} while(--r);
				p += dalign;
			} while(--cy);
			break;
#endif
#if defined(SUPPORT_16BPP)
		case 16:
			do {
				r = cx;
				do {
					*(UINT16 *)p = fg.pal16;
					p += vram->xalign;
				} while(--r);
				p += dalign;
			} while(--cy);
			break;
#endif
#if defined(SUPPORT_24BPP)
		case 24:
			do {
				r = cx;
				do {
					p[RGB24_R] = fg.pal32.p.r;
					p[RGB24_G] = fg.pal32.p.g;
					p[RGB24_B] = fg.pal32.p.b;
					p += vram->xalign;
				} while(--r);
				p += dalign;
			} while(--cy);
			break;
#endif
#if defined(SUPPORT_32BPP)
		case 32:
			do {
				r = cx;
				do {
					*(UINT32 *)p = fg.pal32.d;
					p += vram->xalign;
				} while(--r);
				p += dalign;
			} while(--cy);
			break;
#endif
	}
}

void cmndraw_setfg(const CMNVRAM *vram, const UINT8 *src,
										int x, int y, CMNPAL fg) {

const UINT8	*p;
	UINT8	*q;
	UINT8	cy;
	int		dalign;
	UINT8	c;
	UINT8	bit;
	UINT8	cx;

	if (vram == NULL) {
		return;
	}
	p = src + 2;
	q = vram->ptr + (x * vram->xalign) + (y * vram->yalign);
	dalign = vram->yalign - (vram->xalign * src[0]);
	cy = src[1];
	do {
		cx = src[0];
		bit = 0;
		c = 0;
		switch(vram->bpp) {
#if defined(SUPPORT_8BPP)
			case 8:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*q = fg.pal8;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_16BPP)
			case 16:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*(UINT16 *)q = fg.pal16;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_24BPP)
			case 24:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						q[RGB24_R] = fg.pal32.p.r;
						q[RGB24_G] = fg.pal32.p.g;
						q[RGB24_B] = fg.pal32.p.b;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_32BPP)
			case 32:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*(UINT32 *)q = fg.pal32.d;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
		}
		q += dalign;
	} while(--cy);
}

void cmndraw_setpat(const CMNVRAM *vram, const UINT8 *src,
										int x, int y, CMNPAL bg, CMNPAL fg) {

const UINT8	*p;
	UINT8	*q;
	UINT8	cy;
	int		dalign;
	UINT8	c;
	UINT8	bit;
	UINT8	cx;

	p = src + 2;
	q = vram->ptr + (x * vram->xalign) + (y * vram->yalign);
	dalign = vram->yalign - (vram->xalign * src[0]);
	cy = src[1];
	do {
		cx = src[0];
		bit = 0;
		c = 0;
		switch(vram->bpp) {
#if defined(SUPPORT_8BPP)
			case 8:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*q = fg.pal8;
					}
					else {
						*q = bg.pal8;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_16BPP)
			case 16:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*(UINT16 *)q = fg.pal16;
					}
					else {
						*(UINT16 *)q = bg.pal16;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_24BPP)
			case 24:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						q[RGB24_R] = fg.pal32.p.r;
						q[RGB24_G] = fg.pal32.p.g;
						q[RGB24_B] = fg.pal32.p.b;
					}
					else {
						q[RGB24_R] = bg.pal32.p.r;
						q[RGB24_G] = bg.pal32.p.g;
						q[RGB24_B] = bg.pal32.p.b;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
#if defined(SUPPORT_32BPP)
			case 32:
				do {
					if (!bit) {
						bit = 0x80;
						c = *p++;
					}
					if (c & bit) {
						*(UINT32 *)q = fg.pal32.d;
					}
					else {
						*(UINT32 *)q = bg.pal32.d;
					}
					bit >>= 1;
					q += vram->xalign;
				} while(--cx);
				break;
#endif
		}
		q += dalign;
	} while(--cy);
}


/* ---- */

void cmddraw_text8(CMNVRAM *vram, int x, int y, const char *str, CMNPAL fg) {

	UINT	s;
const UINT8	*ptr;
	UINT8	src[10];

	if ((vram == NULL) || (str == NULL)) {
		return;
	}
	src[0] = 0;
	src[1] = 7;
	while(*str) {
		s = (UINT)(*str++);
		ptr = NULL;
		if ((s >= 0x20) && (s < 0x80)) {
			ptr = minifont + (s - 0x20) * 8;
		}
		else if ((s >= 0xa0) && (s < 0xe0)) {
			ptr = minifont + (s - 0xa0 + 0x60) * 8;
		}
		if (ptr == NULL) {
			continue;
		}
		src[0] = ptr[0];
		CopyMemory(src + 2, ptr + 1, 7);
		cmndraw_setfg(vram, src, x, y, fg);
		x += ptr[0] + 1;
	}
}
