/**
 * @file	externalopna.cpp
 * @brief	�O�� OPNA ���t�N���X�̓���̒�`���s���܂�
 */

#include "compiler.h"
#include "externalopna.h"
#include "externalchipscheduler.h"
#include "keydisp.h"

/**
 * �R���X�g���N�^
 * @param[in] pChip �`�b�v
 * @param[in] nClock �N���b�N
 */
CExternalOpna::CExternalOpna(IExternalChip* pChip, UINT nClock)
	: CExternalPsg(pChip)
	, m_bHasPsg(false)
	, m_bHasRhythm(false)
	, m_bHasADPCM(false)
{
	memset(m_cAlgorithm, 0, sizeof(m_cAlgorithm));
	memset(m_cTtl, 0x7f, sizeof(m_cTtl));

#if defined(YM2612_DEBUG)
	ZeroMemory(m_nCount, sizeof(m_nCount));
	m_nOther = 0;
	m_nLastTick = CExternalChipScheduler::GetInstance()->Now();
#endif	// defined(YM2612_DEBUG)

	switch (GetChipType())
	{
		case IExternalChip::kYM2608:
			m_bHasPsg = true;
			m_bHasRhythm = true;
			m_bHasADPCM = true;
			break;

		case IExternalChip::kYMF288:
			m_bHasPsg = true;
			m_bHasRhythm = true;
			break;
	}

	memset(m_cReg, 0x00, sizeof(m_cReg));
	memset(m_cReg + 0x030, 0xff, 0x70);
	memset(m_cReg + 0x130, 0xff, 0x70);
	keydisp_bindopna(m_cReg, 6, nClock / 2);
}

/**
 * �f�X�g���N�^
 */
CExternalOpna::~CExternalOpna()
{
}

/**
 * �������Z�b�g
 */
void CExternalOpna::Reset()
{
	memset(m_cAlgorithm, 0, sizeof(m_cAlgorithm));
	memset(m_cTtl, 0x7f, sizeof(m_cTtl));

	memset(m_cReg, 0x00, sizeof(m_cReg));
	memset(m_cReg + 0x030, 0xff, 0x70);
	memset(m_cReg + 0x130, 0xff, 0x70);

	CExternalPsg::Reset();

#if defined(YM2612_DEBUG)
	ZeroMemory(m_nCount, sizeof(m_nCount));
	m_nOther = 0;
	m_nLastTick = CExternalChipScheduler::GetInstance()->Now();
#endif	// defined(YM2612_DEBUG)
}

/**
 * ���W�X�^��������
 * @param[in] timestamp �^�C���X�^���v
 * @param[in] nAddr �A�h���X
 * @param[in] cData �f�[�^
 */
void CExternalOpna::WriteRegisterEvent(ExternalChipTimestamp timestamp, UINT nAddr, UINT8 cData)
{
#if defined(YM2612_DEBUG)
	UINT32 nNow = CExternalChipScheduler::GetInstance()->Now();
	while ((nNow - m_nLastTick) >= (EXTERNALCHIPSCHEDULER_MULTIPLE * 1000U))
	{
		UINT nTotal = 0;
		for (UINT i = 0; i < 10; i++)
		{
			nTotal += m_nCount[i];
		}
		if (nTotal)
		{
			printf("%5dHz -", nTotal);
			for (UINT i = 0; i < 10; i++)
			{
				printf(" %4d", m_nCount[i]);
				m_nCount[i] = 0;
			}
			if (m_nOther)
			{
				printf(" + %d", m_nOther);
			}
			printf("\n");
		}
		m_nLastTick += (EXTERNALCHIPSCHEDULER_MULTIPLE * 1000U);
		m_nOther = 0;
	}
	if (nAddr == 0x2a)
	{
		m_nCount[(nNow - m_nLastTick) / (EXTERNALCHIPSCHEDULER_MULTIPLE * 100U)]++;
	}
	else
	{
		m_nOther++;
	}
#endif	// defined(YM2612_DEBUG)

	if (nAddr < 0x10)
	{
		CExternalPsg::WriteRegisterEvent(timestamp, nAddr, cData);
	}
	else
	{
		nAddr &= 0x1ff;
		m_cReg[nAddr] = cData;
		if (nAddr == 0x28)
		{
			keydisp_opna(m_cReg, 0x28);
		}

		if ((nAddr & 0xf0) == 0x40)
		{
			// ttl
			m_cTtl[((nAddr & 0x100) >> 4) + (nAddr & 15)] = cData;
		}
		else if ((nAddr & 0xfc) == 0xb0)
		{
			// algorithm
			m_cAlgorithm[((nAddr & 0x100) >> 6) + (nAddr & 3)] = cData;
		}
		CExternalChipEvent::WriteRegisterEvent(timestamp, nAddr, cData);
	}
}

/**
 * �~���[�g
 * @param[in] bMute �~���[�g
 */
void CExternalOpna::Mute(bool bMute)
{
	const int nVolume = (bMute) ? -127 : 0;
	for (UINT ch = 0; ch < 3; ch++)
	{
		SetVolume(ch + 0, nVolume);
		SetVolume(ch + 4, nVolume);
	}
	CExternalPsg::Mute(bMute);
}

/**
 * ���H�����[���ݒ�
 * @param[in] nChannel �`�����l��
 * @param[in] nVolume ���H�����[���l
 */
void CExternalOpna::SetVolume(UINT nChannel, int nVolume)
{
	const ExternalChipTimestamp now = CExternalChipScheduler::GetInstance()->Now();
	const UINT nBaseReg = (nChannel & 4) ? 0x140 : 0x40;

	//! �A���S���Y�� �X���b�g �}�X�N
	static const UINT8 s_opmask[] = {0x08, 0x08, 0x08, 0x08, 0x0c, 0x0e, 0x0e, 0x0f};
	UINT8 cMask = s_opmask[m_cAlgorithm[nChannel & 7] & 7];
	const UINT8* pTtl = m_cTtl + ((nChannel & 4) << 2);

	int nOffset = nChannel & 3;
	do
	{
		if (cMask & 1)
		{
			int nTtl = (pTtl[nOffset] & 0x7f) - nVolume;
			if (nTtl < 0)
			{
				nTtl = 0;
			}
			else if (nTtl > 0x7f)
			{
				nTtl = 0x7f;
			}
			CExternalChipEvent::WriteRegisterEvent(now, nBaseReg + nOffset, static_cast<UINT8>(nTtl));
		}
		nOffset += 4;
		cMask >>= 1;
	} while (cMask != 0);
}
