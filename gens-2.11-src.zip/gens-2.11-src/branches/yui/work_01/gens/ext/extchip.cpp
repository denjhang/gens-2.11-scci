/**
 * @file	extchip.cpp
 * @brief	�O���`�b�v���t�N���X�̓���̒�`���s���܂�
 */

#include "compiler.h"
#include "extchip.h"
#include "externalchipmanager.h"
#include "externalchiptimestamp.h"
#include "externaldcsg.h"
#include "externalopna.h"
#include "keydisp.h"

//! �B��̃C���X�^���X�ł�
CExtChip CExtChip::sm_instance;

/**
 * �R���X�g���N�^
 */
CExtChip::CExtChip()
	: m_pOpn2(NULL)
	, m_pDcsg(NULL)
{
}

/**
 * �f�X�g���N�^
 */
CExtChip::~CExtChip()
{
	Uninitialize();
}

/**
 * ������
 */
void CExtChip::Initialize()
{
	keydisp_initialize();

	CExternalChipManager* pManager = CExternalChipManager::GetInstance();
	pManager->Initialize();
	if (m_pOpn2 == NULL)
	{
		m_pOpn2 = static_cast<CExternalOpna*>(pManager->GetInterface(IExternalChip::kYM3438, 7670454));
	}
	if (m_pDcsg == NULL)
	{
		m_pDcsg = static_cast<CExternalDcsg*>(pManager->GetInterface(IExternalChip::kSN76489, 3579545));
	}
}

/**
 * ���
 */
void CExtChip::Uninitialize()
{
	CExternalChipManager::GetInstance()->Deinitialize();
	m_pOpn2 = NULL;
	m_pDcsg = NULL;
}

/**
 * ���Z�b�g
 */
void CExtChip::Reset()
{
	CExternalChipManager::GetInstance()->Reset();
	CExternalChipTimestamp::GetInstance()->Reset();
}

/**
 * �~���[�g
 * @param[in] bMute �~���[�g �t���O
 */
void CExtChip::Mute(bool bMute)
{
	CExternalChipManager::GetInstance()->Mute(bMute);
}

/**
 * OPN2
 * @param[in] nAddress �A�h���X
 * @param[in] cData �f�[�^
 */
void CExtChip::WriteOpn2(unsigned int nAddress, unsigned char cData)
{
	if (m_pOpn2)
	{
		const ExternalChipTimestamp timestamp = CExternalChipTimestamp::GetInstance()->Get();
		m_pOpn2->WriteRegisterEvent(timestamp, nAddress, cData);
	}
}

/**
 * DCSG
 * @param[in] cData �f�[�^
 */
void CExtChip::WriteDcsg(unsigned char cData)
{
	if (m_pDcsg)
	{
		const ExternalChipTimestamp timestamp = CExternalChipTimestamp::GetInstance()->Get();
		m_pDcsg->WriteRegisterEvent(timestamp, 0, cData);
	}
}

/**
 * ����
 */
void CExtChip::Sync()
{
	CExternalChipTimestamp::GetInstance()->Sync();
}

/**
 * �T�C�N���o��
 * @param[in] mc68kcycles MC68000 �T�C�N��
 * @param[in] z80cycles Z80 �T�C�N��
 */
void CExtChip::AddCycles(unsigned int mc68kcycles, unsigned int z80cycles)
{
	CExternalChipTimestamp* pTimestamp = CExternalChipTimestamp::GetInstance();
	pTimestamp->Add(mc68kcycles, z80cycles);
	pTimestamp->Sync();
}

// ----

void extchip_reset(void)
{
	CExtChip::GetInstance()->Reset();
}

void extchip_writeopn2(unsigned int nAddress, unsigned char cData)
{
	CExtChip::GetInstance()->WriteOpn2(nAddress, cData);
}

void extchip_writedcsg(unsigned char cData)
{
	CExtChip::GetInstance()->WriteDcsg(cData);
}
