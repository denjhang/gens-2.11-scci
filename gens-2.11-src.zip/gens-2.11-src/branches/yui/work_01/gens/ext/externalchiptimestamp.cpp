/**
 * @file	externalchiptimestamp.cpp
 * @brief	�O�����t�^�C���X�^���v �N���X�̓���̒�`���s���܂�
 */

#include "compiler.h"
#include "externalchiptimestamp.h"
#include "externalchipscheduler.h"
#include "misc/debuglog.h"

#define TIMING_BY_Z80			/*!< Z80 ���x�[�X�ɂ��� */

#define MCLOCK_NTSC 53693175

#include "Mem_M68k.h"
#include "vdp_io.h"
#if defined(TIMING_BY_Z80)
#include "z80.h"
#else	// defined(TIMING_BY_Z80)
extern "C" unsigned int main68k_readOdometer();
#endif	// defined(TIMING_BY_Z80)

//! �B��̃C���X�^���X�ł�
CExternalChipTimestamp CExternalChipTimestamp::sm_instance;

/**
 * �R���X�g���N�^
 * @param[in] pChip �`�b�v
 */
CExternalChipTimestamp::CExternalChipTimestamp()
{
	Reset();
}

/**
 * ���Z�b�g
 */
void CExternalChipTimestamp::Reset()
{
	const DWORD dwTick = CExternalChipScheduler::GetInstance()->Now();

	m_dwCurrentTick = dwTick;
	m_dwLastTick = dwTick;
	m_dwCycles = 0;

	const UINT nFrameRate = (VDP_Status & 1) ? 50 : 60;

#if defined(TIMING_BY_Z80)

	const DWORD dwCpuClock = CPL_Z80 * VDP_Num_Lines * nFrameRate;
	m_dwCpuClock = (dwCpuClock) ? dwCpuClock : (MCLOCK_NTSC / 15);

#else	// defined(TIMING_BY_Z80)

	const DWORD dwCpuClock = CPL_M68K * VDP_Num_Lines * nFrameRate;
	m_dwCpuClock = (dwCpuClock) ? dwCpuClock : (MCLOCK_NTSC / 7);

#endif	// defined(TIMING_BY_Z80)
}

/**
 * �t���[�����Ƃɓ���
 */
void CExternalChipTimestamp::Sync()
{
	// 100ms �ȓ��łȂ��ꍇ�̓��Z�b�g (��������)
	const DWORD dwNow = CExternalChipScheduler::GetInstance()->Now();
	const LONG nPastTick = dwNow - m_dwLastTick;

	// �o��
	const DWORD dwEstimateTick = m_dwCycles / (m_dwCpuClock / (EXTERNALCHIPSCHEDULER_MULTIPLE * 1000U));

	// 100ms �ȓ��łȂ��ꍇ�̓��Z�b�g (��������)
	const LONG nDiff = static_cast<LONG>(dwEstimateTick - nPastTick);

	if (abs(nDiff) >= (EXTERNALCHIPSCHEDULER_MULTIPLE * 20U))
	{
		DEBUGLOG(TEXT("desync @ %fmsec"), static_cast<float>(nDiff) / EXTERNALCHIPSCHEDULER_MULTIPLE);
		m_dwLastTick = dwNow;
		m_dwCycles = 0;
	}
}

/**
 * ����CPU���Ԃ𓾂�
 * @return TICK
 */
ExternalChipTimestamp CExternalChipTimestamp::Get() const
{
#if defined(TIMING_BY_Z80)

	const UINT nClock = m_dwCycles + z80_Read_Odo(&M_Z80);

#else	// defined(TIMING_BY_Z80)

	const UINT nClock = m_dwCycles + main68k_readOdometer();

#endif	// defined(TIMING_BY_Z80)

	// �o��
	const DWORD dwPast = nClock / (m_dwCpuClock / (EXTERNALCHIPSCHEDULER_MULTIPLE * 1000U));
	return m_dwLastTick + dwPast + (EXTERNALCHIPSCHEDULER_MULTIPLE * 40U);
}

/**
 * �T�C�N���v�Z
 */
void CExternalChipTimestamp::Add(unsigned int mc68kcycles, unsigned int z80cycles)
{
#if defined(TIMING_BY_Z80)

	m_dwCycles += z80cycles;

#else	// defined(TIMING_BY_Z80)

	m_dwCycles += mc68kcycles;

#endif	// defined(TIMING_BY_Z80)

	if (m_dwCycles >= m_dwCpuClock)
	{
		m_dwCycles -= m_dwCpuClock;
		m_dwLastTick += EXTERNALCHIPSCHEDULER_MULTIPLE * 1000U;
	}
}
