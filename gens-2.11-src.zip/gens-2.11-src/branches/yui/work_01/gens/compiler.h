/**
 * @file	compiler.h
 * @brief	include file for standard system include files,
 *			or project specific include files that are used frequently,
 *			but are changed infrequently
 */

#pragma once

#include <stdio.h>
#include <tchar.h>
#include <windows.h>

#include "misc/vc6macros.h"

typedef unsigned char UINT8;
typedef unsigned short UINT16;
typedef signed int SINT32;
typedef INT_PTR INTPTR;

#define SUPPORT_16BPP
#define SUPPORT_32BPP

#ifndef	NELEMENTS
#define	NELEMENTS(a)	((UINT)(sizeof(a) / sizeof(a[0])))
#endif
